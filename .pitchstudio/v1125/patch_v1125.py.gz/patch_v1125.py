#!/usr/bin/env python3
"""BEAT flow v1.12.5: A/B/C em mesma posição (prévia de tom e andamento).
Preserva o botão A/B anterior, arquivos, exportação, UI existente e YouTube.
"""
from pathlib import Path
import sys
root=Path(sys.argv[1]).resolve()
main=root/'app/src/main/java/br/com/timachado/pitchstudio/MainActivity.kt'
s=main.read_text('utf-8')
def sub(a,b):
 global s
 n=s.count(a)
 if n!=1:raise SystemExit(f'Marcador ABC esperado 1, obtido {n}: {a[:100]!r}')
 s=s.replace(a,b,1)
sub('    private lateinit var qualitySpinner: Spinner', '''    private lateinit var qualitySpinner: Spinner
    private data class AbcPreset(val tone: Int, val cents: Int, val tempo: Double)
    private var abcEnabled = false
    private var abcActive = 1
    private var abcPreviousUseProcessed = false
    private var abcB: AbcPreset? = null
    private var abcC: AbcPreset? = null
    private var abcPanel: LinearLayout? = null
    private var abcStatus: TextView? = null''')
sub('''    private fun setSemitone(value: Int, process: Boolean = true) {
        semitones = value.coerceIn(-12, 12)''', '''    private fun setSemitone(value: Int, process: Boolean = true) {
        if (abcEnabled) stopAbcComparison()
        semitones = value.coerceIn(-12, 12)''')
sub('''    private fun setCents(value: Int, process: Boolean = true) {
        cents = value.coerceIn(-100, 100)''', '''    private fun setCents(value: Int, process: Boolean = true) {
        if (abcEnabled) stopAbcComparison()
        cents = value.coerceIn(-100, 100)''')
sub('''    private fun setSpeedValue(value: Double, process: Boolean = true) {
        speed = value.coerceIn(0.5, 2.0)''', '''    private fun setSpeedValue(value: Double, process: Boolean = true) {
        if (abcEnabled) stopAbcComparison()
        speed = value.coerceIn(0.5, 2.0)''')
sub('''    private fun applyPitchPreset(semitoneValue: Int, centsValue: Int) {
        semitones = semitoneValue.coerceIn(-12, 12)''', '''    private fun applyPitchPreset(semitoneValue: Int, centsValue: Int) {
        if (abcEnabled) stopAbcComparison()
        semitones = semitoneValue.coerceIn(-12, 12)''')
sub('''    private fun toggleAb() {
        val o = original ?: return''', '''    private fun toggleAb() {
        if (abcEnabled) stopAbcComparison()
        val o = original ?: return''')
code='''    /** A, B e C compartilham o mesmo relógio e o mesmo AudioTrack após ativar a
     * comparação; setPreviewParams não reabre o arquivo nem volta ao início.
     * A qualidade do DSP exportado não é falsamente simulada na prévia instantânea.
     */
    private fun toggleAbcComparison() {
        val source = original ?: run {
            toast("Importe uma música para usar a comparação A/B/C.")
            return
        }
        if (abcEnabled) { stopAbcComparison(); return }
        abcB = AbcPreset(semitones, cents, speed)
        if (abcC == null) abcC = AbcPreset((semitones + 2).coerceIn(-12,12), cents, speed)
        abcPreviousUseProcessed = useProcessed
        abcEnabled = true
        abcPanel?.visibility = View.VISIBLE
        // Usa fonte única para evitar reiniciar a música ao alternar tonalidades.
        val at = player.fraction()
        player.setProject(source, at)
        useProcessed = false
        updateAbButton()
        selectAbc(1)
    }

    private fun selectAbc(slot: Int) {
        if (!abcEnabled) return
        val selection = when(slot) {
            0 -> AbcPreset(0,0,1.0)
            1 -> abcB
            2 -> abcC
            else -> null
        } ?: return
        val src = original ?: return
        // Não reposicionar o playhead se o arquivo original ainda estiver tocando.
        if (player.project !== src) player.setProject(src, player.fraction())
        val pitch = 2.0.pow((selection.tone + selection.cents / 100.0) / 12.0).toFloat()
        player.setPreviewParams(pitch,selection.tempo.toFloat())
        abcActive=slot
        val signed=if (selection.tone>0) "+${selection.tone}" else "${selection.tone}"
        abcStatus?.text="${listOf("A · Original","B · Atual","C · Alternativa")[slot]} · Tom $signed · " +
            String.format(java.util.Locale("pt","BR"),"%.2fx",selection.tempo) +
            " · posição sincronizada"
        waveform.waveform=src.waveform
    }

    private fun stopAbcComparison() {
        if (!abcEnabled) return
        val fraction=player.fraction()
        abcEnabled=false
        abcPanel?.visibility=View.GONE
        useProcessed=abcPreviousUseProcessed
        val o=original
        if (o!=null) {
            val output=if(useProcessed && processedGeneration==processingGeneration) processed else null
            val target=output ?: o
            player.setProject(target,fraction)
            if (target !== o && output != null) player.setPreviewParams(1f,1f)
            else applyPreviewParams()
            waveform.waveform=target.waveform
        }
        updateAbButton()
    }

    private fun editAbcAlternative() {
        if (!abcEnabled) return
        val current=abcC ?: abcB ?: return
        val layout=LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL
            setPadding(dp(22),dp(6),dp(22),dp(4))
        }
        val toneTitle=text("Tom: ${current.tone} semitons",14f,false)
        val toneSeek=SeekBar(this).apply { max=24; progress=current.tone+12 }
        toneSeek.setOnSeekBarChangeListener(simpleSeek {toneTitle.text="Tom: ${it-12} semitons"})
        layout.addView(toneTitle);layout.addView(toneSeek)
        val speedTitle=text(String.format(java.util.Locale("pt","BR"),"Velocidade: %.2fx",current.tempo),14f,false)
        val speedControl=SeekBar(this).apply { max=150; progress=((current.tempo-0.5)*100).roundToInt() }
        speedControl.setOnSeekBarChangeListener(simpleSeek {
            speedTitle.text=String.format(java.util.Locale("pt","BR"),"Velocidade: %.2fx",0.5+it/100.0)
        })
        layout.addView(speedTitle);layout.addView(speedControl)
        layout.addView(text("A prévia instantânea compara tom e velocidade. Qualidade de renderização segue o editor.",12f,false))
        MaterialAlertDialogBuilder(this)
            .setTitle("Configurar versão C")
            .setView(layout)
            .setNegativeButton("Cancelar",null)
            .setPositiveButton("Guardar C") { _, _ ->
                abcC=AbcPreset(toneSeek.progress-12,current.cents,
                    0.5+speedControl.progress/100.0)
                selectAbc(2)
            }.show()
    }

'''
sub('''    private fun toggleAb() {''',code+'    private fun toggleAb() {')
sub('''    private fun cleanupProjects() {
        flushLibraryAutosave()''', '''    private fun cleanupProjects() {
        // Não acessar/abrir arquivos ao destruir Activity depois do player.release().
        abcEnabled=false
        abcPanel?.visibility=View.GONE
        abcB=null;abcC=null
        flushLibraryAutosave()''')
sub('''            if (kicker == "COMECE POR AQUI") {''', '''            if (kicker == "AGORA NO ESTÚDIO") {
                column.addView(button("Comparar A/B/C") { toggleAbcComparison() },
                    full(dp(48),top=10))
                val subPanel=LinearLayout(this).apply {
                    orientation=LinearLayout.VERTICAL
                    visibility=View.GONE
                }
                val choices=row()
                for ((index,label) in listOf("A · Original","B · Atual","C · Outra").withIndex()) {
                    choices.addView(button(label) { selectAbc(index) },
                        LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(dp(2),0,dp(2),0)})
                }
                subPanel.addView(choices,full(wrap(),top=8))
                subPanel.addView(button("Configurar C") { editAbcAlternative() },full(dp(48),top=6))
                abcStatus=text("A / B / C · mesma posição da música",12f,false)
                subPanel.addView(abcStatus,full(wrap(),top=5))
                abcPanel=subPanel
                column.addView(subPanel,full(wrap()))
            }
            if (kicker == "COMECE POR AQUI") {''')
assert s.count('private fun toggleAbcComparison()')==1
assert s.count('button("Comparar A/B/C")')==1
assert 'toggleAb()' in s
assert 'YouTubeImporter' in s or 'YouTubeBrowserActivity' in s
main.write_text(s,'utf-8')
gradle=root/'app/build.gradle.kts'
g=gradle.read_text('utf-8')
for a,b in (('versionCode = 35','versionCode = 36'),('versionName = "1.12.4"','versionName = "1.12.5"')):
 if g.count(a)!=1:raise SystemExit('versao base nao encontrada: '+a)
 g=g.replace(a,b,1)
gradle.write_text(g,'utf-8')
print('BEAT flow v1.12.5: player A/B/C sincronizado sem alterar A/B existente.')

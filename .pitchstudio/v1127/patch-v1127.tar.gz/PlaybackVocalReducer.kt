package br.com.timachado.pitchstudio

import kotlin.math.sqrt

/**
 * Limpeza do residual instrumental após a inferência MDX-Net.
 * A estimativa vocal é uma referência: se estiver ligeiramente subestimada,
 * o playback ainda conterá voz. Ajustamos somente o ganho subtraído,
 * de forma limitada e coerente entre canais; o stem vocal fica intacto.
 */
internal object PlaybackVocalReducer {
    const val MAX_VOCAL_GAIN = 1.60f
    const val RAMP = 0.0025f

    /** Calcula a escala least-squares limitada; não reprocessa áudio original. */
    fun estimateGain(
        mixtureLeft: FloatArray, mixtureRight: FloatArray,
        vocalLeft: FloatArray, vocalRight: FloatArray,
        start: Int, length: Int,
        alignment: Int
    ): Float {
        require(length > 0 && start >= 0 && start + length <= vocalLeft.size &&
            start + length <= vocalRight.size)
        require(start + length + alignment <= mixtureLeft.size &&
            start + length + alignment <= mixtureRight.size)
        var vocalEnergy = 0.0
        var mixEnergy = 0.0
        var cross = 0.0
        var n = 0
        // Subamostragem evita trabalho extra nas músicas longas.
        for (i in start until start + length step 4) {
            val vl = vocalLeft[i]
            val vr = vocalRight[i]
            val ml = mixtureLeft[i + alignment]
            val mr = mixtureRight[i + alignment]
            if (!vl.isFinite() || !vr.isFinite() || !ml.isFinite() || !mr.isFinite()) continue
            val v = vl.toDouble() + vr.toDouble()
            val m = ml.toDouble() + mr.toDouble()
            // Ambos os canais conservam o mesmo ganho, preservando a imagem estéreo.
            vocalEnergy += v * v
            mixEnergy += m * m
            cross += v * m
            ++n
        }
        if (n == 0 || vocalEnergy < 1e-7 || mixEnergy < 1e-7 || cross <= 0.0) return 1f
        val similarity = cross / sqrt(vocalEnergy * mixEnergy)
        if (!similarity.isFinite() || similarity < 0.18) return 1f
        val candidate = cross / vocalEnergy
        return if (candidate.isFinite()) candidate.toFloat().coerceIn(1f, MAX_VOCAL_GAIN) else 1f
    }

    fun ramp(current: Float, target: Float): Float {
        val safeTarget = if (target.isFinite()) target.coerceIn(1f, MAX_VOCAL_GAIN) else 1f
        val safeCurrent = if (current.isFinite()) current.coerceIn(1f, MAX_VOCAL_GAIN) else 1f
        return (safeCurrent + (safeTarget - safeCurrent) * RAMP)
            .coerceIn(1f, MAX_VOCAL_GAIN)
    }

    fun instrumental(mixture: Float, vocal: Float, gain: Float): Float =
        (mixture - vocal * gain).takeIf { it.isFinite() }?.coerceIn(-1f, 1f) ?: 0f
}

package br.com.timachado.pitchstudio

import org.junit.Assert.*
import org.junit.Test
import kotlin.math.sin

class PlaybackVocalReducerTest {
    @Test fun reducesUnderestimatedLeadVocalAndKeepsInstrument() {
        val n=8192; val offset=4096
        val vocals=FloatArray(n){ i -> (0.29*sin(2*Math.PI*220*i/44100)).toFloat() }
        val backing=FloatArray(n){ i -> (0.2*sin(2*Math.PI*330*i/44100)).toFloat() }
        val predicted=FloatArray(n){ i -> vocals[i]*0.76f }
        val mix=FloatArray(n+offset){ i -> if(i<offset)0f else vocals[i-offset]+backing[i-offset] }
        val g=PlaybackVocalReducer.estimateGain(mix,mix,predicted,predicted,0,n,offset)
        assertTrue(g>1.05f)
        assertTrue(g<=PlaybackVocalReducer.MAX_VOCAL_GAIN)
        var before=0.0;var after=0.0
        for(i in 0 until n) {
            val r0=mix[i+offset]-predicted[i]
            val r1=PlaybackVocalReducer.instrumental(mix[i+offset],predicted[i],g)
            before+=(r0-backing[i])*(r0-backing[i])
            after+=(r1-backing[i])*(r1-backing[i])
        }
        assertTrue("Menor vazamento vocal",after<before*0.35)
    }

    @Test fun noVocalLeavesOriginalAndOriginalVocalUnmodified() {
        val n=512;val offset=5
        val mix=FloatArray(n+offset){0.25f}
        val voice=FloatArray(n)
        val g=PlaybackVocalReducer.estimateGain(mix,mix,voice,voice,0,n,offset)
        assertEquals(1f,g,0.0001f)
        assertEquals(.25f,PlaybackVocalReducer.instrumental(.25f,0f,g),0.00001f)
        assertEquals(0f,voice[0],0f)
    }

    @Test fun limiterKeepsFiniteResult() {
        assertEquals(1f,PlaybackVocalReducer.ramp(1f,Float.POSITIVE_INFINITY),0.0001f)
        assertTrue(PlaybackVocalReducer.instrumental(1f,2f,1.6f).isFinite())
    }
}

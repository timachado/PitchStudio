#!/usr/bin/env python3
"""BEAT flow v1.12.7: reduzir resíduo vocal no playback, sem alterar Voz nem UI."""
from pathlib import Path
import sys
root=Path(sys.argv[1]).resolve()
pkg=root/'app/src/main/java/br/com/timachado/pitchstudio'
src=Path(__file__).resolve().parent
engine=pkg/'VocalStemSeparator.kt'
s=engine.read_text(encoding='utf-8')
def replace(old,new):
 global s
 n=s.count(old)
 if n!=1:raise SystemExit(f'v1127: marcador não único ({n}): {old[:100]}')
 s=s.replace(old,new,1)
replace('''            val pendingR = FloatArray(VocalChunkPlan.OVERLAP_FRAMES)
            val voiceBuffer''','''            val pendingR = FloatArray(VocalChunkPlan.OVERLAP_FRAMES)
            var playbackGain = 1f
            val voiceBuffer''')
replace('''                            val vocalsL = istft(inferred, 0)
                            val vocalsR = istft(inferred, 2)
                            for (i in 0 until amount) {''','''                            val vocalsL = istft(inferred, 0)
                            val vocalsR = istft(inferred, 2)
                            // O ganho instrumental é estimado usando a voz prevista
                            // e a mesma janela PCM; não modifica o stem Voz.
                            // Em músicas com mistura de instrumentos, o limite
                            // evita super-subtração agressiva e distorção.
                            // Atualizar o perfil de remoção em janelas curtas:
                            // trechos cantados e instrumentais não compartilham
                            // uma única estimativa de ganho para 5+ segundos.
                            var localGain = 1f
                            for (i in 0 until amount) {''')
replace('''                                val b0 = (left[i+FFT_SIZE] - v0).coerceIn(-1f,1f)
                                val b1 = (right[i+FFT_SIZE] - v1).coerceIn(-1f,1f)''','''                                // Aumenta apenas a subtração dos componentes
                                // efetivamente correlacionados com o stem vocal.
                                // O vocal isolado é salvo com v0/v1, sem mudanças.
                                if (beatOut != null) {
                                    if (i % 16384 == 0) {
                                        localGain = PlaybackVocalReducer.estimateGain(
                                            left, right, vocalsL, vocalsR, i,
                                            min(16384, emit - i), FFT_SIZE
                                        )
                                    }
                                    playbackGain = PlaybackVocalReducer.ramp(playbackGain, localGain)
                                }
                                val b0 = PlaybackVocalReducer.instrumental(
                                    left[i+FFT_SIZE], vL, playbackGain)
                                val b1 = PlaybackVocalReducer.instrumental(
                                    right[i+FFT_SIZE], vR, playbackGain)''')
# vL/vR originais mantidos para evitar clip antes da subtração.
replace('''                                val v0 = (if (mono) (vL+vR)*0.5f else vL).coerceIn(-1f,1f)
                                val v1 = vR.coerceIn(-1f,1f)''','''                                val v0 = (if (mono) (vL+vR)*0.5f else vL).coerceIn(-1f,1f)
                                val v1 = vR.coerceIn(-1f,1f)''') if False else None
# No estéreo fica vL/vR; mono combina predição antes da saída instrumental.
s=s.replace('''                                    left[i+FFT_SIZE], vL, playbackGain)''','''                                    left[i+FFT_SIZE], if (mono) (vL+vR)*0.5f else vL, playbackGain)''',1)
s=s.replace('''                                    right[i+FFT_SIZE], vR, playbackGain)''','''                                    right[i+FFT_SIZE], if (mono) (vL+vR)*0.5f else vR, playbackGain)''',1)
assert s.count('PlaybackVocalReducer.instrumental(')==2
engine.write_text(s,encoding='utf-8')
(pkg/'PlaybackVocalReducer.kt').write_text((src/'PlaybackVocalReducer.kt').read_text(encoding='utf-8'),encoding='utf-8')
unit=root/'app/src/test/java/br/com/timachado/pitchstudio'
(unit/'PlaybackVocalReducerTest.kt').write_text((src/'PlaybackVocalReducerTest.kt').read_text(encoding='utf-8'),encoding='utf-8')
gradle=root/'app/build.gradle.kts';g=gradle.read_text(encoding='utf-8')
for old,new in [('versionCode = 37','versionCode = 38'),('versionName = "1.12.6"','versionName = "1.12.7"')]:
 if g.count(old)!=1:raise SystemExit('Base v1126 incompatível: '+old)
 g=g.replace(old,new,1)
gradle.write_text(g,encoding='utf-8')
print('BEAT flow 1.12.7: cleaner adaptativo só no Playback, Voz intacta.')

package br.com.timachado.pitchstudio

import kotlin.math.sqrt

/**
 * Confidence gate for a SECOND neural pass applied only to the instrumental.
 * The first vocal stem is never modified. If the second pass does not look
 * like a weaker, aligned continuation of the first stem, use the original
 * first-pass instrumental unchanged.
 */
internal object PlaybackResidualRefiner {
    private const val MAX_SECOND_PASS = 0.85f
    private const val MAX_SECOND_TO_FIRST_ENERGY = 0.62
    private const val MIN_COHERENCE = 0.18
    const val RAMP = 0.0025f

    fun strength(
        voiceL: FloatArray, voiceR: FloatArray,
        residualVoiceL: FloatArray, residualVoiceR: FloatArray,
        frames: Int
    ): Float {
        require(frames in 1..minOf(voiceL.size, voiceR.size,
            residualVoiceL.size, residualVoiceR.size))
        var voiceEnergy = 0.0
        var residualEnergy = 0.0
        var cross = 0.0
        for (i in 0 until frames step 4) {
            val a = voiceL[i].toDouble()
            val b = voiceR[i].toDouble()
            val c = residualVoiceL[i].toDouble()
            val d = residualVoiceR[i].toDouble()
            if (!a.isFinite() || !b.isFinite() || !c.isFinite() || !d.isFinite())
                return 0f
            voiceEnergy += a*a + b*b
            residualEnergy += c*c + d*d
            cross += a*c + b*d
        }
        if (voiceEnergy < 1e-7 || residualEnergy < 1e-8 ||
            residualEnergy / voiceEnergy > MAX_SECOND_TO_FIRST_ENERGY || cross <= 0.0)
            return 0f
        val coherence = cross / sqrt(voiceEnergy * residualEnergy)
        if (!coherence.isFinite() || coherence <= MIN_COHERENCE) return 0f
        return (((coherence - MIN_COHERENCE) / 0.5).coerceIn(0.0, 1.0) *
            MAX_SECOND_PASS).toFloat()
    }

    fun ramp(previous: Float, target: Float): Float =
        (previous.coerceIn(0f, MAX_SECOND_PASS) +
            (target.coerceIn(0f, MAX_SECOND_PASS) -
                previous.coerceIn(0f, MAX_SECOND_PASS))*RAMP)
            .coerceIn(0f, MAX_SECOND_PASS)

    fun clean(instrumental: Float, residualVoice: Float, strength: Float): Float =
        (instrumental - residualVoice * strength)
            .takeIf { it.isFinite() }?.coerceIn(-1f, 1f) ?: 0f
}

package br.com.timachado.pitchstudio

import org.junit.Assert.*
import org.junit.Test
import kotlin.math.sin

class PlaybackResidualRefinerTest {
    @Test fun coherentResidualVocalGetsSuppressed() {
        val n=8192
        val lead=FloatArray(n) { i -> (0.32 * sin(i.toDouble()*0.023)).toFloat() }
        val original=FloatArray(n) { i -> lead[i]*0.76f }
        val leftover=FloatArray(n) { i -> lead[i]*0.24f }
        val amount=PlaybackResidualRefiner.strength(original,original,leftover,leftover,n)
        assertTrue(amount > 0.75f)
        val baseline=leftover.map { it.toDouble()*it }.sum()
        val cleaned=leftover.map { PlaybackResidualRefiner.clean(it,it,amount).toDouble() }.map { it*it }.sum()
        assertTrue(cleaned < baseline*0.07)
    }

    @Test fun unrelatedInstrumentDoesNotPassGate() {
        val n=8192
        val voice=FloatArray(n){i->(0.3*sin(i.toDouble()*0.024)).toFloat()}
        val guitar=FloatArray(n){i->(0.3*sin(i.toDouble()*0.055)).toFloat()}
        val gain=PlaybackResidualRefiner.strength(voice,voice,guitar,guitar,n)
        assertEquals(0f,gain,0.0001f)
    }

    @Test fun antifaseVoiceIsNotLostAndSilenceIsUntouched() {
        val n=8192
        val voice=FloatArray(n){i->(0.3*sin(i.toDouble()*0.02)).toFloat()}
        val negative=FloatArray(n){i->-voice[i]}
        val residual=FloatArray(n){i->voice[i]*0.23f}
        val negativeResidual=FloatArray(n){i->-residual[i]}
        val gain=PlaybackResidualRefiner.strength(voice,negative,residual,negativeResidual,n)
        assertTrue(gain > .75f)
        assertEquals(0f,PlaybackResidualRefiner.strength(voice,negative,FloatArray(n),FloatArray(n),n),0.0f)
    }

    @Test fun clipsInvalidValuesToSilence() {
        assertEquals(0f,PlaybackResidualRefiner.clean(Float.NaN,0.1f,0.8f),0.0f)
        assertEquals(0f,PlaybackResidualRefiner.ramp(0f,0f),0.0f)
    }
}

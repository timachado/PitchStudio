#!/usr/bin/env python3
"""BEAT flow v1.12.9: optionally refine only PLAYBACK with a gated second ONNX pass."""
from pathlib import Path
import sys
root = Path(sys.argv[1]).resolve()
pkg = root/'app/src/main/java/br/com/timachado/pitchstudio'
testpkg = root/'app/src/test/java/br/com/timachado/pitchstudio'
artifacts = Path(__file__).parent
sep = pkg/'VocalStemSeparator.kt'
s=sep.read_text(encoding='utf-8')
def once(before,after):
    global s
    assert s.count(before)==1, f'Expected once ({s.count(before)}): {before[:100]}'
    s=s.replace(before,after,1)
once('''            var playbackGain = 1f
            val voiceBuffer''','''            var playbackGain = 1f
            var residualStrength = 0f
            val voiceBuffer''')
needle='''                            val vocalsL = istft(inferred, 0)
                            val vocalsR = istft(inferred, 2)
                            // O ganho instrumental é estimado usando a voz prevista'''
replacement='''                            val vocalsL = istft(inferred, 0)
                            val vocalsR = istft(inferred, 2)
                            // Segunda análise SOMENTE para a saída instrumental.
                            // Reestima voz que ainda sobrou após a primeira remoção.
                            // O stem Voz original não é tocado ou reprocessado.
                            val extraVocal = if (beatOut != null) {
                                val initialGain = PlaybackVocalReducer.estimateGain(
                                    left, right, vocalsL, vocalsR, 0, amount, FFT_SIZE)
                                val draftL = FloatArray(CHUNK)
                                val draftR = FloatArray(CHUNK)
                                for (j in 0 until USABLE) {
                                    draftL[j + FFT_SIZE] = PlaybackVocalReducer.instrumental(
                                        left[j + FFT_SIZE], vocalsL[j], initialGain)
                                    draftR[j + FFT_SIZE] = PlaybackVocalReducer.instrumental(
                                        right[j + FFT_SIZE], vocalsR[j], initialGain)
                                }
                                // Prefixo espelhado fornece contexto ao modelo.
                                for (j in 0 until FFT_SIZE) {
                                    draftL[j] = draftL[2 * FFT_SIZE - j]
                                    draftR[j] = draftR[2 * FFT_SIZE - j]
                                }
                                packed.clear(); inferred.clear()
                                stft(draftL, packed, 0); stft(draftR, packed, 2)
                                packed.rewind()
                                OnnxTensor.createTensor(env, packed.asFloatBuffer(), shape)
                                    .use { tensor ->
                                        session.run(mapOf(name to tensor)).use { results ->
                                            val values = (results[0] as OnnxTensor).floatBuffer
                                            require(values.remaining() == TENSOR_FLOATS)
                                            while (values.hasRemaining()) inferred.putFloat(values.get())
                                        }
                                    }
                                if (Thread.currentThread().isInterrupted)
                                    throw java.io.InterruptedIOException("Separação cancelada.")
                                val nextL = istft(inferred, 0)
                                val nextR = istft(inferred, 2)
                                val confidence = PlaybackResidualRefiner.strength(
                                    vocalsL, vocalsR, nextL, nextR, amount)
                                Triple(nextL, nextR, confidence)
                            } else null
                            // O ganho instrumental é estimado usando a voz prevista'''
once(needle,replacement)
needle2='''                                val b1 = PlaybackVocalReducer.instrumental(
                                    right[i+FFT_SIZE], if (mono) (vL+vR)*0.5f else vR, playbackGain)
                                val slot = min(119,'''
replacement2='''                                val b1 = PlaybackVocalReducer.instrumental(
                                    right[i+FFT_SIZE], if (mono) (vL+vR)*0.5f else vR, playbackGain)
                                if (extraVocal != null) {
                                    residualStrength = PlaybackResidualRefiner.ramp(
                                        residualStrength, extraVocal.third)
                                }
                                val cleaned0 = if (extraVocal != null)
                                    PlaybackResidualRefiner.clean(b0, extraVocal.first[i],
                                        residualStrength) else b0
                                val cleaned1 = if (extraVocal != null)
                                    PlaybackResidualRefiner.clean(b1, extraVocal.second[i],
                                        residualStrength) else b1
                                val slot = min(119,'''
once(needle2,replacement2)
once('''                                    append(beatBuffer,beatOut,b0)
                                    if (!mono) append(beatBuffer,beatOut,b1)
                                    val v = max(kotlin.math.abs(b0),if(mono) 0f else kotlin.math.abs(b1))''','''                                    append(beatBuffer,beatOut,cleaned0)
                                    if (!mono) append(beatBuffer,beatOut,cleaned1)
                                    val v = max(kotlin.math.abs(cleaned0),if(mono) 0f else kotlin.math.abs(cleaned1))''')
sep.write_text(s,encoding='utf-8')
(pkg/'PlaybackResidualRefiner.kt').write_text((artifacts/'PlaybackResidualRefiner.kt').read_text(encoding='utf-8'),encoding='utf-8')
(testpkg/'PlaybackResidualRefinerTest.kt').write_text((artifacts/'PlaybackResidualRefinerTest.kt').read_text(encoding='utf-8'),encoding='utf-8')
gradle=root/'app/build.gradle.kts'
g=gradle.read_text(encoding='utf-8')
for old,new in (("versionCode = 39","versionCode = 40"), ('versionName = "1.12.8"','versionName = "1.12.9"')):
    assert g.count(old)==1,old
    g=g.replace(old,new,1)
gradle.write_text(g,encoding='utf-8')
print('BEAT flow v1.12.9: segunda inferência condicionada ao instrumental.')

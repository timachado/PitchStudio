package br.com.timachado.pitchstudio

import br.com.timachado.pitchstudio.audio.AudioProject
import java.io.BufferedInputStream
import java.io.DataInputStream
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Sugere PONTOS de mudança (sem fingir reconhecer verso/refrão).
 * Lê PCM float estéreo/mono em blocos: nunca carrega a música toda em RAM.
 * Não grava no projeto; toda sugestão depende de aprovação manual.
 */
internal object TimelineSectionSuggester {
    data class Suggestion(val fraction: Double, val strength: Double)
    private const val BIN_SECONDS = 2.0
    private const val SAMPLE_STRIDE = 32L
    private const val MAX_SUGGESTIONS = 12
    private const val MIN_DISTANCE_SECONDS = 9.0

    fun suggest(
        source: AudioProject,
        existing: List<TimelineSections.Marker>,
        cancelled: () -> Boolean = { false }
    ): List<Suggestion> {
        require(source.channels in 1..2 && source.sampleRate in 8000..192000)
        require(source.frames >= 0 && source.pcmFile.isFile)
        val bytesPerFrame = source.channels * 4L
        require(source.pcmFile.length() == source.frames * bytesPerFrame) { "PCM incompleto." }
        if (source.durationSeconds < 25) return emptyList()
        val countBins = ceil(source.durationSeconds / BIN_SECONDS).toInt()
        require(countBins <= 7200) { "Faixa longa demais para análise de seções." }
        val energy = DoubleArray(countBins)
        val activity = DoubleArray(countBins)
        val counts = LongArray(countBins)
        val frameBytes = source.channels * 4
        val blockFrames = 8192
        val block = ByteArray(blockFrames * frameBytes)
        var frameStart = 0L
        var previous = 0.0
        DataInputStream(BufferedInputStream(FileInputStream(source.pcmFile), 128 * 1024)).use { stream ->
            while (frameStart < source.frames) {
                if (cancelled()) throw InterruptedException("Análise cancelada.")
                val framesToRead = min(blockFrames.toLong(), source.frames - frameStart).toInt()
                stream.readFully(block, 0, framesToRead * frameBytes)
                val pcm = ByteBuffer.wrap(block, 0, framesToRead * frameBytes)
                    .order(ByteOrder.LITTLE_ENDIAN)
                for (i in 0 until framesToRead) {
                    val frame = frameStart + i
                    if (frame % SAMPLE_STRIDE != 0L) continue
                    val offset = i * frameBytes
                    val left = pcm.getFloat(offset)
                    val right = if (source.channels == 2) pcm.getFloat(offset + 4) else left
                    val sample = ((left.toDouble() + right.toDouble()) * .5)
                        .takeIf { it.isFinite() }?.coerceIn(-1.0, 1.0) ?: 0.0
                    val bin = ((frame.toDouble() / source.sampleRate) / BIN_SECONDS).toInt()
                        .coerceIn(0, countBins - 1)
                    energy[bin] += sample * sample
                    activity[bin] += abs(sample - previous)
                    counts[bin]++
                    previous = sample
                }
                frameStart += framesToRead
            }
        }
        val rms = DoubleArray(countBins) { i ->
            sqrt(energy[i] / max(1L, counts[i]).toDouble())
        }
        val detail = DoubleArray(countBins) { i ->
            activity[i] / max(1L, counts[i]).toDouble()
        }
        val scores = ArrayList<Suggestion>()
        fun average(v: DoubleArray, from: Int, until: Int): Double {
            var total = 0.0
            for (i in from until until) total += v[i]
            return total / (until - from)
        }
        // Comparar a distribuição dinâmica antes/depois (janelas ~6s).
        for (bin in 3 until countBins - 4) {
            val before = average(rms, bin - 3, bin)
            val after = average(rms, bin, bin + 3)
            val beforeDetail = average(detail, bin - 3, bin)
            val afterDetail = average(detail, bin, bin + 3)
            val dynamics = abs(ln((after + .001) / (before + .001)))
            val timbreProxy = abs(ln((afterDetail + .002) / (beforeDetail + .002)))
            val score = dynamics + timbreProxy * .35
            val second = bin * BIN_SECONDS
            if (score < .42 || second < 6 || source.durationSeconds - second < 8) continue
            val fraction = second / source.durationSeconds
            if (existing.any { abs(it.fraction - fraction) * source.durationSeconds < 8 }) continue
            scores.add(Suggestion(fraction, score))
        }
        // Melhor candidato por região, sem sobrecarregar o usuário.
        val picked = ArrayList<Suggestion>()
        for (candidate in scores.sortedByDescending { it.strength }) {
            if (picked.size == MAX_SUGGESTIONS) break
            if (picked.all {
                    abs(it.fraction - candidate.fraction) * source.durationSeconds >= MIN_DISTANCE_SECONDS
                }) picked.add(candidate)
        }
        return picked.sortedBy { it.fraction }
    }
}

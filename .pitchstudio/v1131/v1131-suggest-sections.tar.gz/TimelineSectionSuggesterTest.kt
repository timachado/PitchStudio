package br.com.timachado.pitchstudio

import br.com.timachado.pitchstudio.audio.AudioProject
import org.junit.Assert.*
import org.junit.Test
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.sin

class TimelineSectionSuggesterTest {
    private fun createAudio(duration: Int, transitions: IntArray, channels: Int = 2): AudioProject {
        val file = File.createTempFile("beatflow-sections-", ".f32")
        file.deleteOnExit()
        val rate = 8000
        val bytes = ByteBuffer.allocate(4096 * channels * 4).order(ByteOrder.LITTLE_ENDIAN)
        file.outputStream().buffered().use { out ->
            for (frame in 0 until duration * rate) {
                val time = frame.toDouble() / rate
                val segment = transitions.count { time >= it }
                val amplitude = if (segment % 2 == 0) .10 else .72
                val sample = (amplitude * sin(2.0 * PI * 440.0 * time)).toFloat()
                repeat(channels) { bytes.putFloat(sample) }
                if (!bytes.hasRemaining()) {
                    out.write(bytes.array(), 0, bytes.position())
                    bytes.clear()
                }
            }
            if (bytes.position() > 0) out.write(bytes.array(), 0, bytes.position())
        }
        return AudioProject("Falsa música de teste", file, rate, channels, duration * rate.toLong(), 1f, floatArrayOf(1f))
    }

    @Test fun suggestsMajorEnergyTransitionsInTimeOrder() {
        val audio = createAudio(72, intArrayOf(20, 42, 56))
        val result = TimelineSectionSuggester.suggest(audio, emptyList())
        assertTrue(result.isNotEmpty())
        assertTrue(result.all { it.fraction in 0.0..1.0 })
        assertEquals(result.sortedBy { it.fraction }, result)
        assertTrue(result.any { kotlin.math.abs(it.fraction * 72 - 20) <= 6 })
        assertTrue(result.any { kotlin.math.abs(it.fraction * 72 - 42) <= 6 })
    }

    @Test fun neverOverwritesNearbyManualMarks() {
        val audio = createAudio(52, intArrayOf(20, 35))
        val result = TimelineSectionSuggester.suggest(audio,
            listOf(TimelineSections.Marker(20.0/52, "Refrão")))
        assertTrue(result.none { kotlin.math.abs(it.fraction * 52 - 20) < 8.0 })
    }

    @Test fun handlesSilenceAndShortClips() {
        val audio=createAudio(28, intArrayOf())
        assertTrue(TimelineSectionSuggester.suggest(audio,emptyList()).size <= 2)
        val small=createAudio(10,intArrayOf())
        assertTrue(TimelineSectionSuggester.suggest(small,emptyList()).isEmpty())
    }

    @Test fun cancellationDoesNotWriteToProject() {
        val audio=createAudio(30,intArrayOf(13))
        try {
            TimelineSectionSuggester.suggest(audio, emptyList()) { true }
            fail("Esperado cancelamento")
        } catch (_: InterruptedException) { }
    }
}

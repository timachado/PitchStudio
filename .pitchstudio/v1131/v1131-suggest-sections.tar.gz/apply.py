#!/usr/bin/env python3
"""BEAT flow v1.13.1 — sugestão de seções, sem editar motor de áudio."""
from pathlib import Path
import hashlib, sys
root=Path(sys.argv[1]).resolve()
base=Path(__file__).resolve().parent
main=root/'app/src/main/java/br/com/timachado/pitchstudio/MainActivity.kt'
assert hashlib.sha256(main.read_bytes()).hexdigest()=='e3373517bbfb0150e39e806a7fcc1de88723fe0d5039c99a80adf48db3cb7ee5', 'MainActivity base divergiu; não alterar layout existente'
s=main.read_text(encoding='utf-8')
def once(a,b):
    global s
    if s.count(a)!=1:raise RuntimeError('Marcador da interface mudou: '+a[:70])
    s=s.replace(a,b,1)
once('    private var songSections: List<TimelineSections.Marker> = emptyList()', '    private var songSections: List<TimelineSections.Marker> = emptyList()'+'\n    private var sectionSuggestionGeneration = 0')
once('    private fun showSongSections() {', '    /** Sugestões não destrutivas: usuário aprova e classifica cada trecho. */\n    private fun suggestSongSections() {\n        val source = original ?: run {\n            toast("Importe uma música antes de analisar trechos.")\n            return\n        }\n        val generation = ++sectionSuggestionGeneration\n        val existing = songSections.toList()\n        timelineStatus?.text = "Analisando mudanças de intensidade na música…"\n        executor.execute {\n            try {\n                val suggestions = TimelineSectionSuggester.suggest(source, existing) {\n                    Thread.currentThread().isInterrupted || generation != sectionSuggestionGeneration\n                }\n                handler.post {\n                    if (generation != sectionSuggestionGeneration || original !== source || isFinishing) return@post\n                    refreshSongSections()\n                    if (suggestions.isEmpty()) {\n                        MaterialAlertDialogBuilder(this)\n                            .setTitle("Análise de trechos")\n                            .setMessage("Nenhuma mudança suficientemente evidente foi encontrada. Você pode continuar marcando os trechos manualmente.")\n                            .setPositiveButton("Entendi", null).show()\n                    } else showSuggestedSongSections(suggestions)\n                }\n            } catch (_: InterruptedException) {\n                // Troca de música ou cancelamento da Activity; não mostrar sugestão antiga.\n            } catch (error: Exception) {\n                handler.post {\n                    if (generation == sectionSuggestionGeneration && !isFinishing) {\n                        refreshSongSections()\n                        toast("Não foi possível analisar a música: " + (error.message ?: "erro de leitura"))\n                    }\n                }\n            }\n        }\n    }\n\n    private fun showSuggestedSongSections(suggestions: List<TimelineSectionSuggester.Suggestion>) {\n        val choices = suggestions.map { "Possível mudança · " + formatFraction(it.fraction) }\n            .toTypedArray()\n        MaterialAlertDialogBuilder(this)\n            .setTitle("Sugestões — confirme cada trecho")\n            .setItems(choices) { _, chosen ->\n                val suggestion = suggestions[chosen]\n                player.seekFraction(suggestion.fraction)\n                MaterialAlertDialogBuilder(this)\n                    .setTitle("Marcar trecho em " + formatFraction(suggestion.fraction))\n                    .setItems(TimelineSections.TYPES.toTypedArray()) { _, type ->\n                        try {\n                            if (songSections.any {\n                                kotlin.math.abs(it.fraction - suggestion.fraction) *\n                                    (original?.durationSeconds ?: 0.0) < 8.0\n                            }) {\n                                toast("Já existe uma marcação próxima deste ponto.")\n                            } else {\n                                songSections = TimelineSections.add(songSections,\n                                    TimelineSections.Marker(suggestion.fraction,\n                                        TimelineSections.TYPES[type]))\n                                persistSongSections()\n                                statusLabel.text = "Trecho confirmado em " + formatFraction(suggestion.fraction)\n                            }\n                        } catch (error: Exception) { toast(error.message ?: "Falha ao marcar trecho.") }\n                    }\n                    .setNegativeButton("Cancelar", null).show()\n            }.setNegativeButton("Fechar", null).show()\n    }\n\n'+'    private fun showSongSections() {')
once('                column.addView(timelineActions,full(wrap(),top=8))', '                column.addView(timelineActions,full(wrap(),top=8))\n                column.addView(button("Sugerir trechos automaticamente") { suggestSongSections() },full(dp(48),top=6))')
once('    private fun cleanupProjects() {\n', '    private fun cleanupProjects() {\n        ++sectionSuggestionGeneration\n')
assert 'YouTubeBrowserActivity.EXTRA_FILE_PATH' in s
main.write_text(s,encoding='utf-8')
for filename,dest in [
    ('TimelineSectionSuggester.kt',main.parent/'TimelineSectionSuggester.kt'),
    ('TimelineSectionSuggesterTest.kt',root/'app/src/test/java/br/com/timachado/pitchstudio/TimelineSectionSuggesterTest.kt')
]:
    dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_bytes((base/filename).read_bytes())
gradle=root/'app/build.gradle.kts'
g=gradle.read_text(encoding='utf-8')
for before,after in [('versionCode = 41','versionCode = 42'),('versionName = "1.13.0"','versionName = "1.13.1"')]:
    if g.count(before)!=1:raise RuntimeError('Versão incompatível: '+before)
    g=g.replace(before,after,1)
gradle.write_text(g,encoding='utf-8')
print('BEAT flow 1.13.1: detector e confirmação de transições integrados.')

package br.com.timachado.pitchstudio

import org.junit.Assert.*
import org.junit.Test

class SectionAutomationTest {
    private val sections=listOf(
        TimelineSections.Marker(.00,"Introdução"),
        TimelineSections.Marker(.25,"Verso"),
        TimelineSections.Marker(.50,"Refrão"),
        TimelineSections.Marker(.75,"Final")
    )

    @Test fun settingsOnlyAffectTheirSection() {
        val a=SectionAutomation.Override(.25,2,.85)
        val b=SectionAutomation.Override(.50,-3,1.12)
        val settings=SectionAutomation.update(sections,listOf(a),b)
        assertNull(SectionAutomation.at(sections,settings,.10))
        assertEquals(a,SectionAutomation.at(sections,settings,.30))
        assertEquals(b,SectionAutomation.at(sections,settings,.51))
        assertNull(SectionAutomation.at(sections,settings,.80))
    }

    @Test fun removingMarkAlsoRemovesOrphanedOverride() {
        val a=SectionAutomation.Override(.25,3,.90)
        val b=SectionAutomation.Override(.50,-2,1.30)
        val remaining=SectionAutomation.normalized(sections.filterNot{it.fraction==.25},listOf(a,b))
        assertEquals(listOf(b),remaining)
        assertEquals(listOf(b),SectionAutomation.remove(listOf(a,b),.25))
    }

    @Test fun rejectsOutOfRangeAndMissingMarkers() {
        for (bad in listOf(SectionAutomation.Override(.25,13,1.0),
            SectionAutomation.Override(.25,0,2.5),
            SectionAutomation.Override(.35,0,1.0))) {
            try {SectionAutomation.update(sections,emptyList(),bad);fail("Inválido aceito: $bad")}
            catch (_: IllegalArgumentException) { /* expected */ }
        }
        assertTrue(SectionAutomation.normalized(sections,listOf(
            SectionAutomation.Override(.25,1,Double.NaN))).isEmpty())
    }

    @Test fun replacingPresetNeverDuplicatesFraction() {
        val a=SectionAutomation.update(sections,emptyList(),SectionAutomation.Override(.50,1,.85))
        val b=SectionAutomation.update(sections,a,SectionAutomation.Override(.50,-4,1.2))
        assertEquals(1,b.size)
        assertEquals(-4,b.single().semitones)
        assertEquals(1.2,b.single().speed,1e-9)
    }
}

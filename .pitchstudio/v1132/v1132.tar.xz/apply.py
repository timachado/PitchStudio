#!/usr/bin/env python3
"""BEAT flow v1.13.2: per-section non-destructive pitch/speed preview and persisted automation.
Does not alter DSP engine, exports, MDX, YouTube, original audio or approved layout.
"""
from pathlib import Path
import sys
root=Path(sys.argv[1]).resolve()
base=root/'app/src/main/java/br/com/timachado/pitchstudio'
main=base/'MainActivity.kt'
lib=base/'ProjectLibrary.kt'
s=main.read_text(encoding='utf-8')
l=lib.read_text(encoding='utf-8')
def once(content,old,new,label=''):
    n=content.count(old)
    if n!=1:raise ValueError(f'{label} expected 1 occurrence, found {n}: {old[:120]!r}')
    return content.replace(old,new,1)

(base/'SectionAutomation.kt').write_text('''package br.com.timachado.pitchstudio

/** Per-section settings for non-destructive live preview, never modifying source PCM. */
internal object SectionAutomation {
    const val MAX = TimelineSections.MAX
    data class Override(val fraction: Double, val semitones: Int, val speed: Double)

    fun normalized(markers: List<TimelineSections.Marker>, items: List<Override>): List<Override> {
        val allowed = TimelineSections.normalized(markers).map { it.fraction }
        return items.asSequence()
            .filter { it.fraction.isFinite() && it.speed.isFinite() }
            .filter { it.semitones in -12..12 && it.speed in 0.5..2.0 }
            .filter { candidate -> allowed.any { kotlin.math.abs(it-candidate.fraction)<0.000001 } }
            .distinctBy { it.fraction }
            .sortedBy { it.fraction }
            .take(MAX).toList()
    }

    fun update(markers: List<TimelineSections.Marker>, items: List<Override>, item: Override): List<Override> {
        require(item.speed.isFinite() && item.speed in 0.5..2.0)
        require(item.semitones in -12..12)
        require(TimelineSections.normalized(markers).any { kotlin.math.abs(it.fraction-item.fraction)<0.000001 })
        return normalized(markers, items.filterNot { kotlin.math.abs(it.fraction-item.fraction)<0.000001 } + item)
    }

    fun remove(items: List<Override>, fraction: Double): List<Override> =
        items.filterNot { kotlin.math.abs(it.fraction-fraction)<0.000001 }

    /** Applies only from section start up to next section marker, not globally. */
    fun at(markers: List<TimelineSections.Marker>, items: List<Override>, position: Double): Override? {
        if (!position.isFinite()) return null
        val start = TimelineSections.normalized(markers).lastOrNull { it.fraction <= position + 1e-10 }
            ?: return null
        return normalized(markers, items).firstOrNull { kotlin.math.abs(it.fraction-start.fraction)<0.000001 }
    }
}
''',encoding='utf-8')

l=once(l,'''    data class Opened(val project: AudioProject, val settings: Settings,
                      val sections: List<TimelineSections.Marker> = emptyList())''','''    data class Opened(val project: AudioProject, val settings: Settings,
                      val sections: List<TimelineSections.Marker> = emptyList(),
                      val sectionOverrides: List<SectionAutomation.Override> = emptyList())''','opened')
lib_methods='''    /** Store section parameters atomically; the original PCM stays byte-identical. */
    @Synchronized fun updateSectionOverrides(context: Context, id: String,
            markers: List<TimelineSections.Marker>, overrides: List<SectionAutomation.Override>) {
        val dir=directory(context,id)
        require(audio(dir).isFile) { "Áudio do projeto ausente." }
        val destination=metadata(dir)
        val obj=JSONObject(destination.readText(Charsets.UTF_8))
        require(obj.getInt("schema")==1) { "Projeto incompatível." }
        val normalized=SectionAutomation.normalized(markers,overrides)
        obj.put("sectionOverrides", JSONArray().apply {
            normalized.forEach { setting -> put(JSONObject().apply {
                put("fraction",setting.fraction)
                put("semitones",setting.semitones)
                put("speed",setting.speed)
            }) }
        })
        obj.put("updatedAt",System.currentTimeMillis())
        val atomic=AtomicFile(destination)
        var output: FileOutputStream?=null
        try {
            output=atomic.startWrite()
            output.write(obj.toString().toByteArray(Charsets.UTF_8))
            atomic.finishWrite(output)
        } catch (error: Exception) {
            if (output!=null) atomic.failWrite(output)
            throw error
        }
    }

    private fun loadSectionOverrides(data: JSONObject,
            markers: List<TimelineSections.Marker>): List<SectionAutomation.Override> {
        val list=data.optJSONArray("sectionOverrides") ?: return emptyList()
        val items=ArrayList<SectionAutomation.Override>()
        for (i in 0 until minOf(list.length(),TimelineSections.MAX)) {
            val obj=list.optJSONObject(i) ?: continue
            items.add(SectionAutomation.Override(
                obj.optDouble("fraction",Double.NaN),
                obj.optInt("semitones",99),
                obj.optDouble("speed",Double.NaN)
            ))
        }
        return SectionAutomation.normalized(markers,items)
    }

'''
l=once(l,'    fun open(context: Context, id: String): Opened {',lib_methods+'    fun open(context: Context, id: String): Opened {','libmethods')
l=once(l,'        return Opened(project, settings,loadSongSections(obj))','''        val markers=loadSongSections(obj)
        return Opened(project, settings,markers,loadSectionOverrides(obj,markers))''','load')

s=once(s,'    private var songSections: List<TimelineSections.Marker> = emptyList()','''    private var songSections: List<TimelineSections.Marker> = emptyList()
    private var sectionOverrides: List<SectionAutomation.Override> = emptyList()
    private var sectionPreviewEnabled = false
    private var sectionPriorProcessed = false
    private var lastSectionPreview: String? = null
    private var sectionPreviewButton: Button? = null''','fields')

# These controls must never silently conflict with per-section preview mode.
for name in ['setSemitone','setCents','setSpeedValue','applyPitchPreset']:
    if name=='setSemitone': before='''    private fun setSemitone(value: Int, process: Boolean = true) {
        if (abcEnabled) stopAbcComparison()'''
    elif name=='setCents':before='''    private fun setCents(value: Int, process: Boolean = true) {
        if (abcEnabled) stopAbcComparison()'''
    elif name=='setSpeedValue':before='''    private fun setSpeedValue(value: Double, process: Boolean = true) {
        if (abcEnabled) stopAbcComparison()'''
    else:before='''    private fun applyPitchPreset(semitoneValue: Int, centsValue: Int) {
        if (abcEnabled) stopAbcComparison()'''
    s=once(s,before,before+'\n        if (sectionPreviewEnabled) stopSectionPreview()',name)

# Comparison and per-section preview must be mutually exclusive.
s=once(s,'    private fun toggleAb() {\n        if (abcEnabled) stopAbcComparison()',
'''    private fun toggleAb() {
        if (sectionPreviewEnabled) stopSectionPreview()
        if (abcEnabled) stopAbcComparison()''','toggleAB')
s=once(s,'    private fun toggleAbcComparison() {',
'''    private fun toggleAbcComparison() {
        if (sectionPreviewEnabled) stopSectionPreview()''','toggleABC')

# Add per-section edit to existing marker action menu with unchanged other actions.
s=once(s,'''            .setItems(arrayOf("Ir para o trecho", "Repetir este trecho", "Renomear", "Excluir marcação"))''',
'''            .setItems(arrayOf("Ir para o trecho", "Repetir este trecho", "Ajustar tom e velocidade", "Renomear", "Excluir marcação"))''','menu')
s=once(s,'''                    2 -> renameSongSection(marker)
                    3 -> {
                        songSections=songSections.filterNot { it == marker }
                        persistSongSections()
                        toast("Marcação excluída.")
                    }''',
'''                    2 -> editSectionAutomation(marker)
                    3 -> renameSongSection(marker)
                    4 -> {
                        songSections=songSections.filterNot { it == marker }
                        sectionOverrides=SectionAutomation.remove(sectionOverrides,marker.fraction)
                        persistSongSections()
                        persistSectionOverrides()
                        toast("Marcação excluída.")
                    }''','menuchoices')

# Keep all other timeline features and add non-destructive live preview.
newmethods='''    private fun persistSectionOverrides() {
        val id=activeProjectId ?: return
        try {
            ProjectLibrary.updateSectionOverrides(this,id,songSections,sectionOverrides)
        } catch (error: Exception) {
            android.util.Log.w("BEATflow-Timeline","Falha ao salvar ajustes por trecho",error)
            toast("Ajustes de trechos não salvos: " + (error.message ?: "erro de armazenamento"))
        }
    }

    private fun editSectionAutomation(marker: TimelineSections.Marker) {
        val old=sectionOverrides.firstOrNull { kotlin.math.abs(it.fraction-marker.fraction)<0.000001 }
        val layout=LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL
            setPadding(dp(20),dp(8),dp(20),dp(6))
        }
        val pitchTitle=text("Tom: ${old?.semitones ?: semitones} semitons",14f,false)
        val pitchControl=SeekBar(this).apply {max=24;progress=(old?.semitones ?: semitones)+12}
        pitchControl.setOnSeekBarChangeListener(simpleSeek {
            pitchTitle.text="Tom: ${it-12} semitons"
        })
        layout.addView(pitchTitle);layout.addView(pitchControl)
        val tempoTitle=text(String.format(java.util.Locale("pt","BR"),
            "Velocidade: %.2fx",old?.speed ?: speed),14f,false)
        val tempoControl=SeekBar(this).apply {
            max=150;progress=(((old?.speed ?: speed)-0.5)*100).roundToInt()
        }
        tempoControl.setOnSeekBarChangeListener(simpleSeek {
            tempoTitle.text=String.format(java.util.Locale("pt","BR"),"Velocidade: %.2fx",0.5+it/100.0)
        })
        layout.addView(tempoTitle);layout.addView(tempoControl)
        layout.addView(text("Este ajuste vale até a próxima marcação. A prévia é não destrutiva; " +
            "WAV/MP3 continuam exportados pelos ajustes gerais do editor.",12f,false))
        MaterialAlertDialogBuilder(this)
            .setTitle("Ajustes do trecho · ${marker.label}")
            .setView(layout)
            .setNegativeButton("Cancelar",null)
            .setNeutralButton("Remover ajuste") { _,_ ->
                sectionOverrides=SectionAutomation.remove(sectionOverrides,marker.fraction)
                persistSectionOverrides()
                lastSectionPreview=null
                applySectionPreviewForPosition()
            }
            .setPositiveButton("Salvar ajuste") { _,_ ->
                try {
                    sectionOverrides=SectionAutomation.update(songSections,sectionOverrides,
                        SectionAutomation.Override(marker.fraction,pitchControl.progress-12,
                            0.5+tempoControl.progress/100.0))
                    persistSectionOverrides()
                    lastSectionPreview=null
                    applySectionPreviewForPosition()
                    toast("Ajuste do trecho salvo.")
                } catch (error: Exception) { toast(error.message ?: "Não foi possível salvar o ajuste.") }
            }.show()
    }

    private fun toggleSectionPreview() {
        if (sectionPreviewEnabled) { stopSectionPreview();return }
        val source=original ?: run {toast("Importe uma música para prévia por trechos.");return}
        if (songSections.isEmpty()) {toast("Marque trechos antes de ativar a prévia.");return}
        if (abcEnabled) stopAbcComparison()
        sectionPriorProcessed=useProcessed
        sectionPreviewEnabled=true
        sectionPreviewButton?.text="■ Encerrar prévia por trechos"
        lastSectionPreview=null
        val position=player.fraction()
        // A fonte original não é modificada nem recriada a cada mudança de trecho.
        if (player.project !== source) player.setProject(source,position)
        useProcessed=false
        updateAbButton()
        waveform.waveform=source.waveform
        applySectionPreviewForPosition()
    }

    private fun stopSectionPreview() {
        if (!sectionPreviewEnabled) return
        sectionPreviewEnabled=false
        sectionPreviewButton?.text="▶ Prévia por trechos"
        lastSectionPreview=null
        useProcessed=sectionPriorProcessed
        val source=original ?: return
        val target=if (useProcessed && processedGeneration==processingGeneration)
            processed ?: source else source
        if (player.project !== target) player.setProject(target,player.fraction())
        if (target !== source) player.setPreviewParams(1f,1f)
        else applyPreviewParams()
        waveform.waveform=target.waveform
        updateAbButton()
    }

    private fun applySectionPreviewForPosition() {
        if (!sectionPreviewEnabled) return
        val source=original ?: return
        if (player.project !== source) return
        val fraction=player.fraction()
        val segment=TimelineSections.normalized(songSections).lastOrNull {it.fraction<=fraction}
        val setting=SectionAutomation.at(songSections,sectionOverrides,fraction)
        val key="${segment?.fraction}:${setting?.semitones ?: semitones}:${setting?.speed ?: speed}"
        if (lastSectionPreview==key) return
        lastSectionPreview=key
        val tone=setting?.semitones ?: semitones
        val tempo=setting?.speed ?: speed
        player.setPreviewParams(2.0.pow(tone/12.0).toFloat(),tempo.toFloat())
        timelineStatus?.text=(segment?.label ?: "Trecho sem marcação") +
            " · prévia tom ${if(tone>0) "+" else ""}$tone · " +
            String.format(java.util.Locale("pt","BR"),"%.2fx",tempo)
    }

'''
s=once(s,'    private fun markA() {',newmethods+'    private fun markA() {','methods')
s=once(s,'        refreshSongSections()\n        val id = activeProjectId ?: return',
'''        refreshSongSections()
        sectionOverrides=SectionAutomation.normalized(songSections,sectionOverrides)
        val id = activeProjectId ?: return''','persist marker sync')
s=once(s,'                songSections=TimelineSections.add(\n                    songSections.filterNot { it==marker },\n                    TimelineSections.Marker(marker.fraction,title))\n                persistSongSections()',
'''                songSections=TimelineSections.add(
                    songSections.filterNot { it==marker },
                    TimelineSections.Marker(marker.fraction,title))
                persistSongSections()''','rename')
# New separate button in existing card; no reflow of other cards.
s=once(s,'''                column.addView(button("Sugerir trechos automaticamente") { suggestSongSections() },full(dp(48),top=6))''',
'''                column.addView(button("Sugerir trechos automaticamente") { suggestSongSections() },full(dp(48),top=6))
                sectionPreviewButton=button("▶ Prévia por trechos") { toggleSectionPreview() }
                column.addView(sectionPreviewButton,full(dp(48),top=6))''','ui')
s=once(s,'''    private val progressTick = object : Runnable {
        override fun run() {
            waveform.progress = player.fraction()''',
'''    private val progressTick = object : Runnable {
        override fun run() {
            waveform.progress = player.fraction()
            applySectionPreviewForPosition()''','tick')
s=once(s,'''                    original = project
                    songSections=loaded.sections
                    refreshSongSections()''',
'''                    original = project
                    songSections=loaded.sections
                    sectionOverrides=loaded.sectionOverrides
                    refreshSongSections()''','loadUi')
s=once(s,'''                val sectionsAtSave = songSections.toList()
                val settings = ProjectLibrary.Settings(''',
'''                val sectionsAtSave = songSections.toList()
                val overridesAtSave = sectionOverrides.toList()
                val settings = ProjectLibrary.Settings(''','saveCapture')
s=once(s,'''                                    persistSongSections()
                                    scheduleLibraryAutosave()''',
'''                                    persistSongSections()
                                    persistSectionOverrides()
                                    scheduleLibraryAutosave()''','saveActive')
s=once(s,'''                                if (original !== source && sectionsAtSave.isNotEmpty()) {
                                    try { ProjectLibrary.updateTimelineSections(this,entry.id,sectionsAtSave) }
                                    catch (error: Exception) {
                                        android.util.Log.w("BEATflow-Timeline","Falha ao preservar trechos no projeto salvo",error)
                                    }
                                }''',
'''                                if (original !== source && sectionsAtSave.isNotEmpty()) {
                                    try {
                                        ProjectLibrary.updateTimelineSections(this,entry.id,sectionsAtSave)
                                        ProjectLibrary.updateSectionOverrides(this,entry.id,sectionsAtSave,overridesAtSave)
                                    } catch (error: Exception) {
                                        android.util.Log.w("BEATflow-Timeline","Falha ao preservar trechos no projeto salvo",error)
                                    }
                                }''','saveOther')
s=once(s,'''    private fun cleanupProjects() {
        ++sectionSuggestionGeneration
        songSections=emptyList()''',
'''    private fun cleanupProjects() {
        ++sectionSuggestionGeneration
        sectionPreviewEnabled=false
        sectionPreviewButton?.text="▶ Prévia por trechos"
        lastSectionPreview=null
        sectionOverrides=emptyList()
        songSections=emptyList()''','cleanup')
# Future export-by-section should be a separate delivery with tested renderer.
assert 'YouTubeBrowserActivity' in s and 'openBeatSeparation()' in s
assert 'sectionPreviewButton' in s and 'SectionAutomation.at' in s
assert 'revisionHistory' in l and 'sectionOverrides' in l
main.write_text(s,encoding='utf-8')
lib.write_text(l,encoding='utf-8')
gradle=root/'app/build.gradle.kts';g=gradle.read_text(encoding='utf-8')
g=once(g,'versionCode = 42','versionCode = 43','code')
g=once(g,'versionName = "1.13.1"','versionName = "1.13.2"','version')
gradle.write_text(g,encoding='utf-8')
print('BEAT flow v1.13.2: ajustes por trecho salvos + prévia PCM não destrutiva.')

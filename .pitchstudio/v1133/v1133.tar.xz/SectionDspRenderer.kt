package br.com.timachado.pitchstudio

import br.com.timachado.pitchstudio.audio.AudioProject
import br.com.timachado.pitchstudio.audio.DspEngine
import br.com.timachado.pitchstudio.audio.DspSettings
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToLong

/**
 * Offline and non-destructive section renderer. Splits PCM into local ranges,
 * processes each with the EXISTING DSP and joins adjacent parts with a 12 ms
 * crossfade. Never edits the original song, markers or library metadata.
 */
internal object SectionDspRenderer {
    private data class Rendered(val file: File, val frames: Long)

    fun render(
        source: AudioProject,
        output: File,
        markers: List<TimelineSections.Marker>,
        overrides: List<SectionAutomation.Override>,
        global: DspSettings,
        onProgress: (Int) -> Unit = {}
    ): AudioProject {
        val frameBytes = source.channels * 4L
        require(source.channels in 1..2 && source.sampleRate > 0 && source.frames > 0)
        require(source.frames <= Long.MAX_VALUE / frameBytes)
        require(source.pcmFile.isFile && source.pcmFile.length() == source.frames * frameBytes) {
            "Arquivo original incompleto."
        }
        require(output.canonicalPath != source.pcmFile.canonicalPath)
        val normalized = TimelineSections.normalized(markers)
        val settings = SectionAutomation.normalized(normalized, overrides)
        require(settings.isNotEmpty()) { "Nenhum trecho tem ajustes para exportar." }
        val bounds = (listOf(0L) + normalized.map {
            (it.fraction * source.frames).roundToLong().coerceIn(1L, source.frames - 1)
        } + listOf(source.frames)).distinct().sorted()
        require(bounds.size >= 2)
        val dir = File(output.parentFile ?: error("Diretório inválido"), "render_${System.nanoTime()}")
        check(dir.mkdirs()) { "Não foi possível criar área temporária para edição." }
        var prev: Rendered? = null
        var prevSkip = 0L
        var written = 0L
        var peak = 0f
        var success = false
        try {
            BufferedOutputStream(FileOutputStream(output), 256 * 1024).use { result ->
                for (index in 0 until bounds.lastIndex) {
                    checkInterrupted()
                    val start = bounds[index]
                    val end = bounds[index + 1]
                    if (end <= start) continue
                    val frameCount = end - start
                    val input = File(dir, "source_$index.f32")
                    val part = File(dir, "processed_$index.f32")
                    copyRange(source.pcmFile, start, frameCount, source.channels, input)
                    val position = (start.toDouble() + frameCount * 0.5) / source.frames
                    val override = SectionAutomation.at(normalized, settings, position)
                    val params = if (override != null) {
                        DspSettings(override.semitones, 0, override.speed, global.quality)
                    } else global
                    val inputProject = AudioProject(source.name, input, source.sampleRate,
                        source.channels, frameCount, source.peak, source.waveform)
                    val processed = try {
                        DspEngine.process(inputProject, part, params) { progress ->
                            checkInterrupted()
                            onProgress(((index + progress / 100.0) * 82.0 /
                                bounds.lastIndex).toInt().coerceIn(0, 82))
                        }
                    } finally { input.delete() }
                    require(processed.frames > 0 && part.length() == processed.frames * frameBytes) {
                        "Falha ao gerar áudio completo para o trecho $index."
                    }
                    val current = Rendered(part, processed.frames)
                    val previous = prev
                    if (previous != null) {
                        val fade = minOf((source.sampleRate * 0.012).toLong().coerceAtLeast(1),
                            (previous.frames - prevSkip) / 4, current.frames / 4)
                        val until = previous.frames - fade
                        peak = max(peak, append(previous.file, prevSkip, until, source.channels, result))
                        written += until - prevSkip
                        if (fade > 0) {
                            peak = max(peak, blend(previous.file, current.file,
                                previous.frames - fade, fade, source.channels, result))
                            written += fade
                        }
                        previous.file.delete()
                        prevSkip = fade
                    }
                    prev = current
                    onProgress(((index + 1) * 82.0 / bounds.lastIndex).toInt().coerceIn(0, 82))
                }
                val last = prev ?: error("Nenhum trecho foi processado.")
                peak = max(peak, append(last.file, prevSkip, last.frames, source.channels, result))
                written += last.frames - prevSkip
                last.file.delete()
            }
            require(written > 0L && output.length() == written * frameBytes) {
                "O áudio renderizado não tem o número de amostras esperado."
            }
            onProgress(100)
            success = true
            return AudioProject(source.name, output, source.sampleRate, source.channels,
                written, peak, source.waveform)
        } finally {
            dir.listFiles()?.forEach { it.delete() }
            dir.delete()
            if (!success) output.delete()
        }
    }

    private fun copyRange(source: File, from: Long, count: Long, channels: Int, dest: File) {
        RandomAccessFile(source, "r").use { input ->
            input.seek(from * channels * 4L)
            BufferedOutputStream(FileOutputStream(dest), 256 * 1024).use { output ->
                var remaining = count * channels * 4L
                val buffer = ByteArray(64 * 1024)
                while (remaining > 0L) {
                    checkInterrupted()
                    val n = input.read(buffer, 0, min(remaining, buffer.size.toLong()).toInt())
                    if (n <= 0) error("A música original terminou antes do fim do trecho.")
                    output.write(buffer, 0, n)
                    remaining -= n
                }
            }
        }
    }

    private fun append(file: File, first: Long, exclusive: Long, channels: Int,
                       output: BufferedOutputStream): Float {
        if (exclusive <= first) return 0f
        var peak = 0f
        val bytesPerFrame = channels * 4L
        RandomAccessFile(file, "r").use { reader ->
            reader.seek(first * bytesPerFrame)
            var remaining = (exclusive - first) * bytesPerFrame
            val buffer = ByteArray(64 * 1024)
            while (remaining > 0) {
                checkInterrupted()
                // Every chunk must contain a complete number of float32 samples.
                val n = min(remaining, buffer.size.toLong()).toInt()
                reader.readFully(buffer, 0, n)
                val bb = ByteBuffer.wrap(buffer, 0, n).order(ByteOrder.LITTLE_ENDIAN)
                while (bb.remaining() >= 4) {
                    val v = bb.float
                    require(v.isFinite()) { "Áudio DSP contém amostras inválidas." }
                    peak = max(peak, abs(v))
                }
                output.write(buffer, 0, n)
                remaining -= n
            }
        }
        return peak
    }

    private fun blend(left: File, right: File, leftStart: Long, frames: Long,
                      channels: Int, output: BufferedOutputStream): Float {
        if (frames == 0L) return 0f
        val count = (frames * channels).toInt()
        val a = ByteArray(count * 4)
        val b = ByteArray(count * 4)
        RandomAccessFile(left, "r").use { reader ->
            reader.seek(leftStart * channels * 4L)
            reader.readFully(a)
        }
        RandomAccessFile(right, "r").use { reader -> reader.readFully(b) }
        val aa = ByteBuffer.wrap(a).order(ByteOrder.LITTLE_ENDIAN)
        val bb = ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN)
        val result = ByteBuffer.allocate(count * 4).order(ByteOrder.LITTLE_ENDIAN)
        var peak = 0f
        for (i in 0 until frames.toInt()) {
            val t = (i + 1f) / (frames + 1f)
            for (ch in 0 until channels) {
                val old = aa.float
                val next = bb.float
                require(old.isFinite() && next.isFinite())
                val sample = old * (1f - t) + next * t
                peak = max(peak, abs(sample))
                result.putFloat(sample)
            }
        }
        output.write(result.array())
        return peak
    }

    private fun checkInterrupted() {
        if (Thread.currentThread().isInterrupted)
            throw java.util.concurrent.CancellationException("Exportação por trechos interrompida.")
    }
}

package br.com.timachado.pitchstudio

import br.com.timachado.pitchstudio.audio.AudioProject
import br.com.timachado.pitchstudio.audio.DspQuality
import br.com.timachado.pitchstudio.audio.DspSettings
import org.junit.Assert.*
import org.junit.Test
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.sin

class SectionDspRendererTest {
    private fun project(dir: File, seconds: Int = 2): AudioProject {
        val frames = 8000L * seconds
        val file = File(dir, "original.f32")
        val buffer = ByteBuffer.allocate((frames * 2 * 4).toInt()).order(ByteOrder.LITTLE_ENDIAN)
        for (i in 0 until frames.toInt()) {
            val sample = (0.3 * sin(2 * PI * 220 * i / 8000)).toFloat()
            buffer.putFloat(sample); buffer.putFloat(-sample)
        }
        file.writeBytes(buffer.array())
        return AudioProject("sample", file, 8000, 2, frames, .3f, floatArrayOf(.3f))
    }

    @Test fun perSectionSpeedChangesTotalFramesAndPreservesSource() {
        val dir = createTempDir(prefix="sections")
        try {
            val source = project(dir)
            val originalBytes = source.pcmFile.readBytes()
            val markers = listOf(TimelineSections.Marker(0.0,"Introdução"),
                TimelineSections.Marker(.5,"Refrão"))
            val changed = listOf(SectionAutomation.Override(.5, 2, 2.0))
            val out = File(dir,"final.f32")
            val result = SectionDspRenderer.render(source,out,markers,changed,
                DspSettings(0,0,1.0,DspQuality.RAPIDA))
            assertTrue(result.frames in 11700..12000)
            assertEquals(result.frames * 8,out.length())
            assertTrue(result.peak > 0f)
            assertArrayEquals(originalBytes, source.pcmFile.readBytes())
            assertTrue(dir.listFiles()!!.none { it.name.startsWith("render_") })
        } finally {dir.deleteRecursively()}
    }

    @Test fun noOverrideIsRejectedRatherThanSilentlyIgnoringUserSettings() {
        val dir = createTempDir(prefix="sections")
        try {
            val p=project(dir,1)
            try {
                SectionDspRenderer.render(p,File(dir,"unused.f32"),emptyList(),emptyList(),DspSettings())
                fail("No override was accepted")
            } catch (_: IllegalArgumentException) { }
            assertEquals(8000L*2*4,p.pcmFile.length())
        } finally {dir.deleteRecursively()}
    }
}

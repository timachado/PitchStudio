#!/usr/bin/env python3
"""Apply BEAT flow v1.13.3 section export upgrade to exact prior v1.13.2 source."""
from pathlib import Path
import subprocess,sys
root=Path(sys.argv[1]).resolve()
source=Path(__file__).resolve().parent
main=root/'app/src/main/java/br/com/timachado/pitchstudio/MainActivity.kt'
gradle=root/'app/build.gradle.kts'
assert 'versionName = "1.13.2"' in gradle.read_text(), 'Unexpected base version'
assert 'WAV por trechos' not in main.read_text(), 'Already patched'
for patch in ('main.patch','gradle.patch'):
  subprocess.run(['patch','--batch','-p1','--input',str(source/patch)],cwd=root,check=True)
for file,destination in (
 ('SectionDspRenderer.kt',root/'app/src/main/java/br/com/timachado/pitchstudio/SectionDspRenderer.kt'),
 ('SectionDspRendererTest.kt',root/'app/src/test/java/br/com/timachado/pitchstudio/SectionDspRendererTest.kt')
):
 assert not destination.exists(),f'Already exists: {file}'
 destination.parent.mkdir(parents=True,exist_ok=True)
 destination.write_bytes((source/file).read_bytes())
assert 'versionName = "1.13.3"' in gradle.read_text()
assert 'WAV por trechos' in main.read_text()
assert 'MP3 por trechos' in main.read_text()
assert 'SectionDspRenderer.render' in main.read_text()
print('BEAT flow 1.13.3: offline crossfaded WAV/MP3 segment rendering integrated.')

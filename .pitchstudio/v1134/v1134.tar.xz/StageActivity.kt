package br.com.timachado.pitchstudio

import android.app.Activity
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import br.com.timachado.pitchstudio.audio.PcmAudioPlayer
import kotlin.math.pow

/** Área totalmente offline para setlists, ensaios, letras e navegação no palco. */
class StageActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private val player = PcmAudioPlayer { handler.post {
        if (!isFinishing && !isDestroyed) {
            status.text = "Música concluída · próxima faixa manual"
            refreshTransport()
        }
    } }
    private var setlistId: String? = null
    private var selectedIndex = -1
    private var stageMode = false
    private lateinit var setlistTitle: TextView
    private lateinit var track: TextView
    private lateinit var lyrics: TextView
    private lateinit var status: TextView
    private lateinit var trackList: LinearLayout
    private lateinit var progress: SeekBar
    private lateinit var position: TextView
    private lateinit var playBtn: MaterialButton
    private lateinit var modeBtn: MaterialButton
    private val progressTick = object : Runnable {
        override fun run() {
            if (!isFinishing && !isDestroyed) {
                progress.progress = (player.fraction() * 1000).toInt().coerceIn(0, 1000)
                val p=player.project
                val duration=p?.let { it.frames.toDouble()/it.sampleRate } ?: 0.0
                position.text="${clock(duration*player.fraction())} / ${clock(duration)}"
                refreshTransport()
                handler.postDelayed(this, 650)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor=Color.rgb(15,18,26)
        window.navigationBarColor=Color.rgb(15,18,26)
        setlistId = getPreferences(MODE_PRIVATE).getString("active_setlist",null)
        buildUi()
        updateUi()
        handler.post(progressTick)
    }
    override fun onPause() {
        super.onPause()
        player.pause()
        refreshTransport()
    }
    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        player.release()
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        super.onDestroy()
    }
    private fun dp(value:Int)=(value*resources.displayMetrics.density).toInt()
    private fun clock(seconds:Double):String {
        val total=seconds.toLong().coerceAtLeast(0)
        return "%02d:%02d".format(total/60,total%60)
    }
    private fun text(value:String,size:Float=16f,strong:Boolean=false):TextView = TextView(this).apply {
        this.text=value
        textSize=size
        setTextColor(if(strong) Color.WHITE else Color.rgb(201,210,226))
        setPadding(0,dp(3),0,dp(3))
        if(strong) setTypeface(typeface,1)
    }
    private fun btn(label:String,action:()->Unit):MaterialButton = MaterialButton(this).apply {
        text=label
        isAllCaps=false
        textSize=14f
        setTextColor(Color.WHITE)
        backgroundTintList=ColorStateList.valueOf(Color.rgb(35,77,86))
        setOnClickListener { try { action() } catch(e:Exception) { report(e) } }
    }
    private fun report(error:Exception) {
        Toast.makeText(this,error.message ?: "Falha ao operar repertório.", Toast.LENGTH_LONG).show()
    }
    private fun full(height:Int=-2,top:Int=6)=LinearLayout.LayoutParams(-1,height).apply { topMargin=dp(top) }
    private fun row()=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
    private fun rowBtn(line:LinearLayout,label:String,action:()->Unit) {
        line.addView(btn(label,action),LinearLayout.LayoutParams(0,dp(51),1f).apply {setMargins(dp(2),0,dp(2),0)})
    }
    private fun buildUi() {
        val column=LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL
            setPadding(dp(18),dp(24),dp(18),dp(40))
            setBackgroundColor(Color.rgb(15,18,26))
        }
        val scroll=ScrollView(this).apply {isFillViewport=true;addView(column)}
        setContentView(scroll)
        column.addView(text("BEAT flow · Palco & Ensaio",24f,true),full(top=2))
        column.addView(text("Repertórios locais · áudio e letras disponíveis offline",13f),full(top=1))
        modeBtn=btn("Ativar Modo Palco") { toggleMode() }
        column.addView(modeBtn,full(dp(54),16))
        setlistTitle=text("Nenhum repertório",20f,true)
        column.addView(setlistTitle,full(top=17))
        val lists=row()
        rowBtn(lists,"Escolher repertório") { chooseSetlist() }
        rowBtn(lists,"Novo repertório") { createSetlist() }
        column.addView(lists,full(top=8))
        val management=row()
        rowBtn(management,"Adicionar música") { addSong() }
        rowBtn(management,"Excluir repertório") { confirmDeleteSetlist() }
        column.addView(management,full(top=4))
        track=text("Selecione uma música do repertório",22f,true)
        column.addView(track,full(top=18))
        position=text("00:00 / 00:00",13f)
        column.addView(position,full(top=2))
        progress=SeekBar(this).apply {
            max=1000
            progressTintList=ColorStateList.valueOf(Color.rgb(68,205,186))
            thumbTintList=ColorStateList.valueOf(Color.rgb(68,205,186))
            setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar:SeekBar?,value:Int,fromUser:Boolean) {
                    if(fromUser)player.seekFraction(value/1000.0)
                }
                override fun onStartTrackingTouch(seekBar:SeekBar?)=Unit
                override fun onStopTrackingTouch(seekBar:SeekBar?)=Unit
            })
        }
        column.addView(progress,full(top=8))
        val transport=row()
        rowBtn(transport,"◀ Anterior") { previousTrack() }
        playBtn=btn("▶ Reproduzir") { player.toggle();refreshTransport() }
        transport.addView(playBtn, LinearLayout.LayoutParams(0,dp(58),1.2f).apply {setMargins(dp(2),0,dp(2),0)})
        rowBtn(transport,"Próxima ▶") { nextTrack() }
        column.addView(transport,full(top=6))
        status=text("O Modo Palco não avança sozinho para evitar surpresas na apresentação.",12f)
        column.addView(status,full(top=7))
        column.addView(text("Letras e anotações",18f,true),full(top=18))
        val lyricButtons=row()
        rowBtn(lyricButtons,"Editar letra") { editLyrics() }
        rowBtn(lyricButtons,"Reordenar músicas") { reorder() }
        column.addView(lyricButtons,full(top=7))
        lyrics=text("Selecione uma música para ver ou editar sua letra.",21f).apply {
            setPadding(dp(14),dp(20),dp(14),dp(20))
            setBackgroundColor(Color.rgb(29,34,47))
        }
        column.addView(lyrics,full(top=10))
        column.addView(text("Músicas do repertório",18f,true),full(top=18))
        trackList=LinearLayout(this).apply {orientation=LinearLayout.VERTICAL}
        column.addView(trackList,full(top=5))
        column.addView(text("Repertórios usam projetos da Biblioteca Inteligente. Nenhum áudio é duplicado.",12f),full(top=13))
    }
    private fun current():StageSetlists.Setlist?=StageSetlists.list(this).firstOrNull {it.id==setlistId}
    private fun selectedId():String?=current()?.songIds?.getOrNull(selectedIndex)
    private fun updateUi() {
        val set=current()
        val names=ProjectLibrary.list(this).associateBy {it.id}
        if(set==null) {
            setlistTitle.text="Nenhum repertório selecionado"
            selectedIndex=-1
        } else {
            setlistTitle.text="${set.title} · ${set.songIds.size} músicas"
            if (selectedIndex>=set.songIds.size) selectedIndex=-1
        }
        val id=selectedId()
        track.text=if(id==null) "Selecione uma música do repertório" else names[id]?.title ?: "Projeto indisponível"
        lyrics.text=if(id==null) "Selecione uma música para ver ou editar a letra." else
            set?.lyrics?.get(id)?.takeIf {it.isNotBlank()} ?: "Sem letra cadastrada. Toque em Editar letra."
        lyrics.textSize=if(stageMode) 27f else 21f
        trackList.removeAllViews()
        set?.songIds?.forEachIndexed {index,songId ->
            val label="${index+1}. ${names[songId]?.title ?: "Projeto indisponível"}"
            val item=btn(if(index==selectedIndex) "▶ $label" else label) {load(index,false)}
            item.backgroundTintList=ColorStateList.valueOf(
                if(index==selectedIndex) Color.rgb(19,125,111) else Color.rgb(35,47,64))
            trackList.addView(item,full(dp(48),4))
        }
        refreshTransport()
    }
    private fun save(set:StageSetlists.Setlist) {StageSetlists.update(this,set);updateUi()}
    private fun chooseSetlist() {
        val items=StageSetlists.list(this)
        if(items.isEmpty()){createSetlist();return}
        MaterialAlertDialogBuilder(this).setTitle("Escolher repertório")
            .setItems(items.map { "${it.title} · ${it.songIds.size} músicas" }.toTypedArray()) {_,which ->
                player.pause();player.setProject(null)
                setlistId=items[which].id;selectedIndex=-1
                getPreferences(MODE_PRIVATE).edit().putString("active_setlist",setlistId).apply()
                updateUi()
            }.setNegativeButton("Cancelar",null).show()
    }
    private fun createSetlist() {
        val name=EditText(this).apply {hint="Nome do repertório";setSingleLine(true);setPadding(dp(22),dp(12),dp(22),dp(12))}
        MaterialAlertDialogBuilder(this).setTitle("Novo repertório")
            .setView(name).setPositiveButton("Criar") {_,_->
                try {
                    val created=StageSetlists.create(this,name.text.toString())
                    player.pause();player.setProject(null)
                    setlistId=created.id;selectedIndex=-1
                    getPreferences(MODE_PRIVATE).edit().putString("active_setlist",setlistId).apply()
                    updateUi()
                }catch(e:Exception){report(e)}
            }.setNegativeButton("Cancelar",null).show()
    }
    private fun confirmDeleteSetlist() {
        val set=current() ?: return
        MaterialAlertDialogBuilder(this).setTitle("Excluir ${set.title}?")
            .setMessage("Remove apenas o repertório e suas letras. Os projetos de áudio continuam salvos.")
            .setPositiveButton("Excluir") {_,_->
                StageSetlists.delete(this,set.id)
                player.pause();player.setProject(null)
                selectedIndex=-1;setlistId=null
                getPreferences(MODE_PRIVATE).edit().remove("active_setlist").apply()
                updateUi()
            }.setNegativeButton("Cancelar",null).show()
    }
    private fun addSong() {
        val set=current() ?: run {chooseSetlist();return}
        val available=ProjectLibrary.list(this).filterNot {it.id in set.songIds}
        if(available.isEmpty()) {
            Toast.makeText(this,"Salve um projeto na Biblioteca Inteligente primeiro.",Toast.LENGTH_LONG).show()
            return
        }
        MaterialAlertDialogBuilder(this).setTitle("Adicionar projeto salvo")
            .setItems(available.map {it.title}.toTypedArray()) {_,index ->
                save(set.copy(songIds=StageSetlistOrder.add(set.songIds,available[index].id)))
            }.setNegativeButton("Cancelar",null).show()
    }
    private fun load(index:Int,autoPlay:Boolean) {
        val set=current() ?: return
        val id=set.songIds.getOrNull(index) ?: return
        val opened=try {ProjectLibrary.open(this,id)} catch(e:Exception) {
            player.pause();player.setProject(null)
            status.text="Projeto indisponível: ${e.message ?: "arquivo ausente"}"
            updateUi();return
        }
        player.pause();player.setProject(opened.project,0.0)
        val s=opened.settings
        val pitch=(2.0).pow((s.semitones+s.cents/100.0)/12.0).toFloat()
        player.setPreviewParams(pitch,s.speed.toFloat())
        player.loopA=if(stageMode)null else s.loopA
        player.loopB=if(stageMode)null else s.loopB
        selectedIndex=index
        status.text="${if(stageMode) "Palco" else "Ensaio"} · ${s.semitones} semitons · ${"%.2f".format(s.speed)}x"
        if(autoPlay)player.play()
        updateUi()
    }
    private fun previousTrack() {
        val ids=current()?.songIds ?: return
        if(ids.isEmpty())return
        load(if(selectedIndex<=0)0 else selectedIndex-1,true)
    }
    private fun nextTrack() {
        val ids=current()?.songIds ?: return
        if(ids.isEmpty())return
        load(if(selectedIndex !in ids.indices) 0 else (selectedIndex+1).coerceAtMost(ids.lastIndex),true)
    }
    private fun refreshTransport() {
        if(::playBtn.isInitialized) playBtn.text=if(player.isPlaying())"Ⅱ Pausar" else "▶ Reproduzir"
    }
    private fun toggleMode() {
        stageMode=!stageMode
        modeBtn.text=if(stageMode) "Sair do Modo Palco · Ensaio" else "Ativar Modo Palco"
        if(stageMode) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val settings=selectedId()?.let { id ->
            try { ProjectLibrary.open(this,id).settings } catch (_:Exception) { null }
        }
        player.loopA=if(stageMode)null else settings?.loopA
        player.loopB=if(stageMode)null else settings?.loopB
        updateUi()
        status.text=if(stageMode) "Modo Palco · tela ativa · próximo manual" else "Modo Ensaio · letras e repertório editáveis"
    }
    private fun editLyrics() {
        val set=current() ?: return
        val id=selectedId() ?: run {
            Toast.makeText(this,"Escolha uma música.",Toast.LENGTH_SHORT).show();return
        }
        val input=EditText(this).apply {
            setText(set.lyrics[id].orEmpty())
            hint="Digite a letra ou anotações de ensaio"
            minLines=8;maxLines=16
            setPadding(dp(18),dp(14),dp(18),dp(14))
            inputType=android.text.InputType.TYPE_CLASS_TEXT or
                android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        }
        MaterialAlertDialogBuilder(this).setTitle("Letra e anotações offline")
            .setView(input).setPositiveButton("Salvar") {_,_->
                val updated=set.lyrics.toMutableMap()
                updated[id]=input.text.toString().take(12000)
                save(set.copy(lyrics=updated))
            }.setNegativeButton("Cancelar",null).show()
    }
    private fun reorder() {
        val set=current() ?: return
        if(set.songIds.isEmpty())return
        val index=selectedIndex.takeIf {it in set.songIds.indices} ?:0
        val title=ProjectLibrary.list(this).firstOrNull {it.id==set.songIds[index]}?.title ?: "Música"
        MaterialAlertDialogBuilder(this).setTitle("Organizar: $title")
            .setItems(arrayOf("Subir no repertório","Descer no repertório","Remover do repertório")) {_,option ->
                val next=when(option){
                    0 -> StageSetlistOrder.move(set.songIds,index,-1)
                    1 -> StageSetlistOrder.move(set.songIds,index,1)
                    else -> StageSetlistOrder.remove(set.songIds,set.songIds[index])
                }
                if(next!=set.songIds) {
                    player.pause();player.setProject(null)
                    selectedIndex=-1
                    save(set.copy(songIds=next))
                }
            }.setNegativeButton("Cancelar",null).show()
    }
}

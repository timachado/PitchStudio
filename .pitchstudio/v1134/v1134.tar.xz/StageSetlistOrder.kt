package br.com.timachado.pitchstudio

/** Immutable, dependency-free operations on the ids in a live setlist. */
internal object StageSetlistOrder {
    const val MAX_SONGS = 120
    fun add(ids: List<String>, id: String): List<String> {
        require(id.isNotBlank())
        if (ids.contains(id) || ids.size >= MAX_SONGS) return ids.toList()
        return ids + id
    }
    fun remove(ids: List<String>, id: String): List<String> = ids.filterNot { it == id }
    fun move(ids: List<String>, index: Int, delta: Int): List<String> {
        if (index !in ids.indices || delta !in -1..1) return ids.toList()
        val dst = index + delta
        if (dst !in ids.indices) return ids.toList()
        return ids.toMutableList().also { java.util.Collections.swap(it, index, dst) }
    }
}

package br.com.timachado.pitchstudio

import org.junit.Assert.*
import org.junit.Test

class StageSetlistOrderTest {
    @Test fun addOnceAndKeepOrder() {
        val ids = listOf("a", "b")
        assertEquals(listOf("a", "b", "c"), StageSetlistOrder.add(ids, "c"))
        assertEquals(ids, StageSetlistOrder.add(ids, "a"))
        assertEquals(ids, StageSetlistOrder.add(ids, "b"))
    }
    @Test fun movingBoundariesDoesNotDropMusic() {
        val ids = listOf("a", "b", "c")
        assertEquals(ids, StageSetlistOrder.move(ids, 0, -1))
        assertEquals(ids, StageSetlistOrder.move(ids, 2, 1))
        assertEquals(listOf("b", "a", "c"), StageSetlistOrder.move(ids, 1, -1))
        assertEquals(listOf("a", "c", "b"), StageSetlistOrder.move(ids, 1, 1))
        assertEquals(ids, StageSetlistOrder.move(ids, -1, 1))
    }
    @Test fun removeOnlyRequestedSong() {
        assertEquals(listOf("a", "c"),StageSetlistOrder.remove(listOf("a", "b", "c"), "b"))
    }
    @Test fun refuseToGrowBeyondLimit() {
        val ids=(0 until StageSetlistOrder.MAX_SONGS).map { it.toString() }
        assertEquals(ids, StageSetlistOrder.add(ids, "other"))
    }
}

package br.com.timachado.pitchstudio

import android.content.Context
import android.util.AtomicFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

/** Repertórios privados e offline. Somente IDs e letras, sem duplicar PCM ou editar projetos. */
internal object StageSetlists {
    private const val MAX_LISTS = 40
    private const val MAX_LYRICS = 12000
    data class Setlist(val id: String, val title: String,
                       val songIds: List<String>, val lyrics: Map<String, String>)
    private fun file(context: Context) = File(context.filesDir, "stage_setlists.json")
    private val validId = Regex("[a-f0-9-]{36}")

    @Synchronized fun list(context: Context): List<Setlist> {
        val f = file(context)
        if (!f.isFile) return emptyList()
        return try {
            val obj = JSONObject(f.readText(Charsets.UTF_8))
            if (obj.optInt("schema") != 1) return emptyList()
            val rows = obj.optJSONArray("setlists") ?: return emptyList()
            val result = ArrayList<Setlist>()
            for (i in 0 until minOf(rows.length(), MAX_LISTS)) {
                val row = rows.optJSONObject(i) ?: continue
                val id = row.optString("id")
                if (!validId.matches(id)) continue
                val ids = row.optJSONArray("songs") ?: JSONArray()
                val songs = ArrayList<String>()
                for (k in 0 until minOf(ids.length(), StageSetlistOrder.MAX_SONGS)) {
                    val song = ids.optString(k)
                    if (validId.matches(song) && song !in songs) songs.add(song)
                }
                val lyrics = HashMap<String, String>()
                val lines = row.optJSONObject("lyrics") ?: JSONObject()
                val iterator = lines.keys()
                while (iterator.hasNext()) {
                    val song = iterator.next()
                    if (song in songs) lyrics[song] = lines.optString(song).take(MAX_LYRICS)
                }
                result.add(Setlist(id, row.optString("title").take(70), songs, lyrics))
            }
            result
        } catch (_: Exception) { emptyList() }
    }

    @Synchronized private fun persist(context: Context, sets: List<Setlist>) {
        require(sets.size <= MAX_LISTS)
        val array = JSONArray()
        for (set in sets) {
            require(validId.matches(set.id) && set.title.isNotBlank())
            val row = JSONObject()
            row.put("id", set.id)
            row.put("title", set.title.take(70))
            row.put("songs", JSONArray().also { songs ->
                for (id in set.songIds.take(StageSetlistOrder.MAX_SONGS)) songs.put(id)
            })
            row.put("lyrics", JSONObject().also { lines ->
                for ((id, lyric) in set.lyrics) if (id in set.songIds)
                    lines.put(id, lyric.take(MAX_LYRICS))
            })
            array.put(row)
        }
        val target = AtomicFile(file(context))
        var output: FileOutputStream? = null
        try {
            output = target.startWrite()
            output.write(JSONObject().put("schema", 1).put("setlists", array)
                .toString().toByteArray(Charsets.UTF_8))
            target.finishWrite(output)
        } catch (err: Exception) {
            if (output != null) target.failWrite(output)
            throw err
        }
    }
    @Synchronized fun create(context: Context, title: String): Setlist {
        val normalized = title.trim().take(70)
        require(normalized.isNotBlank()) { "Informe o nome do repertório." }
        val sets = list(context)
        require(sets.size < MAX_LISTS) { "Limite de repertórios atingido." }
        val created = Setlist(UUID.randomUUID().toString(), normalized, emptyList(), emptyMap())
        persist(context, sets + created)
        return created
    }
    @Synchronized fun update(context: Context, set: Setlist) {
        val sets = list(context)
        require(sets.any { it.id == set.id }) { "Repertório não encontrado." }
        
        require(set.songIds.size <= StageSetlistOrder.MAX_SONGS &&
                set.songIds.all { validId.matches(it) } && set.songIds.distinct().size == set.songIds.size) {
            "O repertório contém projetos indisponíveis."
        }
        persist(context, sets.map { if (it.id == set.id) set else it })
    }
    @Synchronized fun delete(context: Context, id: String) {
        persist(context, list(context).filterNot { it.id == id })
    }
}

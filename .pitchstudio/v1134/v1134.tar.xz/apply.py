#!/usr/bin/env python3
"""Incremental patch BEAT flow 1.13.4 — Modo Palco e Ensaio offline."""
from pathlib import Path
import sys

root=Path(sys.argv[1]).resolve()
base=root/'app/src/main/java/br/com/timachado/pitchstudio'
patch=Path(__file__).resolve().parent
assert (base/'MainActivity.kt').is_file(), 'Project root missing'
for name in ('StageActivity.kt','StageSetlistOrder.kt','StageSetlists.kt'):
    dest=base/name
    assert not dest.exists(), f'Refuse to overwrite existing {name}'
    dest.write_text((patch/name).read_text(encoding='utf-8'),encoding='utf-8')

unit=root/'app/src/test/java/br/com/timachado/pitchstudio'
unit.mkdir(parents=True,exist_ok=True)
target=unit/'StageSetlistOrderTest.kt'
assert not target.exists()
target.write_text((patch/'StageSetlistOrderTest.kt').read_text(encoding='utf-8'),encoding='utf-8')

main=base/'MainActivity.kt'
s=main.read_text(encoding='utf-8')
old='                column.addView(button("Separação com IA · Gerar playback") { openBeatSeparation() }, full(dp(54), top = 9))'
new=old+'''\n                column.addView(button("Modo Palco e Ensaio") {
                    player.pause()
                    refreshPlayButton()
                    startActivity(Intent(this, StageActivity::class.java))
                }, full(dp(54), top = 9))'''
assert s.count(old)==1, 'Unexpected home card'
main.write_text(s.replace(old,new,1),encoding='utf-8')

manifest=root/'app/src/main/AndroidManifest.xml'
s=manifest.read_text(encoding='utf-8')
old='<activity android:name=".TomIdealActivity" android:exported="false" />'
new=old+'\n        <activity android:name=".StageActivity" android:exported="false" />'
assert s.count(old)==1
manifest.write_text(s.replace(old,new,1),encoding='utf-8')

gradle=root/'app/build.gradle.kts'
s=gradle.read_text(encoding='utf-8')
for old,new in (("versionCode = 44","versionCode = 45"),('versionName = "1.13.3"','versionName = "1.13.4"')):
    assert s.count(old)==1, 'Version baseline unexpected: '+old
    s=s.replace(old,new,1)
gradle.write_text(s,encoding='utf-8')
print('BEAT flow 1.13.4 — Stage & Rehearsal module added without changing existing DSP or YouTube.')

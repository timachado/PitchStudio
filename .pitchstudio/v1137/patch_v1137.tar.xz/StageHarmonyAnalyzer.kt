package br.com.timachado.pitchstudio

import java.io.File
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.*

/** Sugestões offline de tonalidade e tríades. Não é transcrição harmônica exata. */
internal object StageHarmonyAnalyzer {
    data class ChordHint(val second: Int, val name: String, val confidence: Double)
    data class Analysis(val key: String?, val confidence: Double, val chords: List<ChordHint>)
    val noteNames = arrayOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")
    private val majorProfile = doubleArrayOf(6.35,2.23,3.48,2.33,4.38,4.09,2.52,5.19,2.39,3.66,2.29,2.88)
    private val minorProfile = doubleArrayOf(6.33,2.68,3.52,5.38,2.60,3.53,2.54,4.75,3.98,2.69,3.34,3.17)
    private const val FFT_SIZE = 4096
    private const val MAX_SECONDS = 36
    private const val MAX_CHORDS = 12

    /** Float32 little-endian, intercalado. Lê uma janela por vez e limita a 36 s. */
    fun analyze(file: File, sampleRate: Int, channels: Int, frames: Long): Analysis? {
        require(sampleRate in 8000..192000 && channels in 1..2)
        if (!file.isFile || frames < sampleRate.toLong() * 5L) return null
        val limit = minOf(frames, sampleRate.toLong() * MAX_SECONDS)
        if (file.length() < limit * channels * 4L) return null
        val stride = max(1, (sampleRate / 11025.0).roundToInt())
        val rate = sampleRate.toDouble() / stride
        val windowFrames = FFT_SIZE * stride
        val windows = minOf(120L, limit / windowFrames).toInt()
        if (windows < 8) return null
        val windowData = ByteArray(windowFrames * channels * 4)
        val spectral = ArrayList<DoubleArray>(windows)
        val real = DoubleArray(FFT_SIZE)
        val imag = DoubleArray(FFT_SIZE)
        FileInputStream(file).buffered(256 * 1024).use { input ->
            repeat(windows) {
                if (Thread.currentThread().isInterrupted) return null
                var pos = 0
                while (pos < windowData.size) {
                    val read = input.read(windowData, pos, windowData.size - pos)
                    if (read <= 0) return null
                    pos += read
                }
                val b = ByteBuffer.wrap(windowData).order(ByteOrder.LITTLE_ENDIAN)
                var peak = 0.0
                for (i in 0 until FFT_SIZE) {
                    b.position(i * stride * channels * 4)
                    var value = 0.0
                    repeat(channels) { value += b.float.toDouble() / channels }
                    if (!value.isFinite()) return null
                    peak = max(peak, abs(value))
                    real[i] = value * (0.5 - 0.5 * cos(2.0 * Math.PI * i / (FFT_SIZE-1)))
                    imag[i] = 0.0
                }
                if (peak < 0.0005) { spectral.add(DoubleArray(12));return@repeat }
                fft(real, imag)
                val chroma = DoubleArray(12)
                val mags = DoubleArray(FFT_SIZE / 2) { k -> hypot(real[k], imag[k]) }
                for (k in 2 until FFT_SIZE / 2 - 1) {
                    val freq = k * rate / FFT_SIZE
                    if (freq < 115.0 || freq > 1150.0) continue
                    val amp = mags[k]
                    if (amp < mags[k-1] || amp <= mags[k+1]) continue
                    val midi = 69.0 + 12.0 * log2(freq / 440.0)
                    val nearest = midi.roundToInt()
                    // Picos entre semitons costumam ser ruído/transientes.
                    if (abs(midi-nearest) > .30) continue
                    val pc = ((nearest % 12) + 12) % 12
                    chroma[pc] += sqrt(amp) / sqrt(freq / 220.0)
                }
                spectral.add(chroma)
            }
        }
        val total = DoubleArray(12)
        spectral.forEach { w -> w.forEachIndexed { index, value -> total[index] += value } }
        if (total.sum() < 1.0) return null
        return summarize(spectral, windowFrames.toDouble() / sampleRate)
    }

    /** Entrada pura para testes sintéticos e correções futuras do algoritmo. */
    internal fun summarize(windows: List<DoubleArray>, secondsPerWindow: Double): Analysis? {
        if (windows.size < 4 || secondsPerWindow <= 0.0 || !secondsPerWindow.isFinite()) return null
        if (windows.any { it.size != 12 || it.any { v -> !v.isFinite() || v < 0 } }) return null
        val aggregate = DoubleArray(12)
        windows.forEach { a ->
            val power = a.sum()
            if (power > 1e-6) for (k in 0..11) aggregate[k] += a[k] / power
        }
        if (aggregate.sum() < 2.0) return null
        val keys = (0..11).flatMap { root ->
            listOf(Triple(root,false,correlation(aggregate,majorProfile,root)),
                   Triple(root,true,correlation(aggregate,minorProfile,root)))
        }.sortedByDescending { it.third }
        val best = keys.first()
        // Retornar indeterminado quando o espectro não discrimina bem a tonalidade.
        val gap = best.third - keys[1].third
        val key = if (best.third > .34 && gap > .015) noteNames[best.first] + if(best.second)"m" else "" else null
        val groups = mutableListOf<ChordHint>()
        val chunk = max(2,(5.0 / secondsPerWindow).roundToInt())
        for (start in windows.indices step chunk) {
            val sub = windows.subList(start, minOf(windows.size,start+chunk))
            if (sub.size < max(2,chunk/2)) break
            val pitches=DoubleArray(12)
            for (a in sub) {
                val total=a.sum()
                if(total > 1e-7)for(i in 0..11) pitches[i] += a[i]/total
            }
            val candidate = bestChord(pitches)
            if(candidate != null) {
                val second = (start * secondsPerWindow).roundToInt()
                // Repetições consecutivas não são novos acordes.
                if (groups.lastOrNull()?.name == candidate.first) continue
                groups.add(ChordHint(second,candidate.first,candidate.second))
                if(groups.size >= MAX_CHORDS)break
            }
        }
        return Analysis(key,(best.third.coerceIn(0.0,1.0)*gap.coerceIn(0.0,1.0)).coerceIn(0.0,1.0),groups)
    }
    private fun bestChord(chroma:DoubleArray):Pair<String,Double>? {
        if(chroma.sum() <= 0.03)return null
        val total=chroma.sum()
        val normalized=DoubleArray(12){chroma[it]/total}
        val ranked = (0..11).flatMap { root -> listOf(false,true).map { minor ->
            val third=(root+if(minor)3 else 4)%12
            val fifth=(root+7)%12
            val support=normalized[root]+normalized[third]+normalized[fifth]
            val coverage=minOf(normalized[root],normalized[third],normalized[fifth])
            Triple(noteNames[root] + if(minor)"m" else "",support+coverage*0.9,coverage)
        }}.sortedByDescending {it.second}
        val first=ranked.first()
        if(first.second < .52 || first.third < .025 || first.second-ranked[1].second < .035)return null
        return first.first to first.second.coerceIn(0.0,1.0)
    }
    private fun correlation(observed:DoubleArray,profile:DoubleArray,root:Int):Double {
        val avgX=observed.average();val avgY=profile.average()
        var a=0.0;var b=0.0;var c=0.0
        for(i in 0..11){val x=observed[(i+root)%12]-avgX;val y=profile[i]-avgY;a+=x*y;b+=x*x;c+=y*y}
        return if(b*c<1e-10)0.0 else a/sqrt(b*c)
    }
    /** In-place radix-2 FFT, sem dependência externa. */
    private fun fft(real:DoubleArray,imag:DoubleArray) {
        val n=real.size
        var j=0
        for(i in 1 until n) {
            var bit=n shr 1
            while(j and bit != 0){j=j xor bit;bit=bit shr 1}
            j=j xor bit
            if(i<j){val ar=real[i];real[i]=real[j];real[j]=ar;val ai=imag[i];imag[i]=imag[j];imag[j]=ai}
        }
        var length=2
        while(length<=n) {
            val angle=-2*Math.PI/length
            val c=cos(angle);val s=sin(angle)
            var pos=0
            while(pos<n) {
                var wr=1.0;var wi=0.0
                for(k in 0 until length/2) {
                    val a=pos+k;val b=a+length/2
                    val tr=wr*real[b]-wi*imag[b];val ti=wr*imag[b]+wi*real[b]
                    real[b]=real[a]-tr;imag[b]=imag[a]-ti;real[a]+=tr;imag[a]+=ti
                    val nr=wr*c-wi*s;wi=wr*s+wi*c;wr=nr
                }
                pos+=length
            }
            length=length shl 1
        }
    }
}

package br.com.timachado.pitchstudio

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.assertNull
import org.junit.Assert.assertNotNull
import org.junit.Test
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.sin

class StageHarmonyAnalyzerTest {
    @Test fun chordTransitionsAndKeyProfile() {
        val notes = listOf(
            intArrayOf(0,4,7), intArrayOf(5,9,0),
            intArrayOf(7,11,2), intArrayOf(0,4,7))
        val windows=(0 until 48).map { i ->
            val chroma=DoubleArray(12){.025}
            notes[(i/12).coerceAtMost(3)].forEach { chroma[it]+=2.0 }
            chroma
        }
        val result=StageHarmonyAnalyzer.summarize(windows,0.42)
        assertNotNull(result)
        val answer=result!!
        assertTrue(answer.chords.isNotEmpty())
        assertEquals("C",answer.chords[0].name)
        assertTrue(answer.chords.any{it.name=="F"})
    }
    @Test fun silenceInvalidInputAndMetadata() {
        assertNull(StageHarmonyAnalyzer.summarize(List(20){DoubleArray(12)},0.4))
        assertNull(StageHarmonyAnalyzer.summarize(listOf(doubleArrayOf(Double.NaN)),1.0))
        assertEquals(12,StageHarmonyAnalyzer.noteNames.size)
    }
    @Test fun sampledPcmIsReadOnlyAndChordDetected() {
        val sampleRate=8000;val seconds=8
        val file=File.createTempFile("beatflow-harmony-", ".f32")
        try {
            val bb=ByteBuffer.allocate(8192).order(ByteOrder.LITTLE_ENDIAN)
            FileOutputStream(file).use { out ->
                repeat(sampleRate*seconds) { i ->
                    val t=i.toDouble()/sampleRate
                    val v=(.23*sin(2*Math.PI*261.626*t)+.23*sin(2*Math.PI*329.628*t)+.23*sin(2*Math.PI*391.995*t)).toFloat()
                    if(bb.remaining()<4){out.write(bb.array(),0,bb.position());bb.clear()}
                    bb.putFloat(v)
                }
                if(bb.position()>0)out.write(bb.array(),0,bb.position())
            }
            val sizeBefore=file.length()
            val result=StageHarmonyAnalyzer.analyze(file,sampleRate,1,seconds.toLong()*sampleRate)
            assertNotNull(result)
            assertTrue(result!!.chords.any{it.name=="C"})
            assertEquals(sizeBefore,file.length())
        } finally {file.delete()}
    }
}

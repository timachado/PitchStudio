#!/usr/bin/env python3
"""BEAT flow v1.13.7: harmony suggestions in offline Stage screen and setlist metadata."""
from pathlib import Path
import sys
root=Path(sys.argv[1]).resolve()
pkg=root/'app/src/main/java/br/com/timachado/pitchstudio'
stage=pkg/'StageActivity.kt'
setlists=pkg/'StageSetlists.kt'

def change(s,old,new,descr):
    n=s.count(old)
    if n!=1:raise ValueError(f'{descr}: expected one, got {n}: {old[:100]!r}')
    return s.replace(old,new,1)

s=stage.read_text(encoding='utf-8')
s=change(s,'    private var tempoBpm: Int? = null', '''    private var harmonyBusy = false
    private var harmonyGeneration = 0
    private var recentHarmony: StageHarmonyAnalyzer.Analysis? = null
    private lateinit var harmonyStatus: TextView
    private lateinit var harmonyChords: TextView
    private var tempoBpm: Int? = null''','harmonic fields')
s=change(s,'        tempoGeneration++\n        tempoBusy=false\n        player.pause()', '        tempoGeneration++\n        tempoBusy=false\n        harmonyGeneration++\n        harmonyBusy=false\n        player.pause()', 'pause cancel')
s=change(s,'        tempoGeneration++\n        tone?.release()', '        tempoGeneration++\n        harmonyGeneration++\n        tone?.release()', 'destroy cancel')
s=change(s,'''        column.addView(bpmControls,full(top=4))
        status=text(''', '''        column.addView(bpmControls,full(top=4))
        column.addView(text("Tonalidade e acordes · sugestões offline",18f,true),full(top=14))
        harmonyStatus=text("Tonalidade: não analisada",13f)
        column.addView(harmonyStatus,full(top=3))
        val harmonyActions=row()
        rowBtn(harmonyActions,"Analisar tonalidade") { analyzeHarmony() }
        rowBtn(harmonyActions,"Corrigir tom") { correctHarmony() }
        rowBtn(harmonyActions,"Salvar harmonia") { saveHarmony() }
        column.addView(harmonyActions,full(top=4))
        harmonyChords=text("Acordes sugeridos aparecerão aqui; confirme pelo ouvido.",13f)
        column.addView(harmonyChords,full(top=4))
        status=text(''', 'harmony panel')
s=change(s,'''        refreshTransport()
    }
    // Controles locais de palco/ensaio''','''        refreshTransport()
        if (::harmonyStatus.isInitialized) refreshHarmony()
    }
    // Controles locais de palco/ensaio''','harmony UI refresh')
s=change(s,'    private fun updateTempoStatus(detail:String?=null) {', '''    private fun refreshHarmony() {
        if (!::harmonyStatus.isInitialized) return
        val saved=selectedId()?.let{ id -> current()?.harmonies?.get(id) }
        val estimate=recentHarmony
        if(estimate!=null) {
            harmonyStatus.text="Tonalidade sugerida: ${estimate.key ?: "indeterminada"} · confira manualmente"
            harmonyChords.text=if(estimate.chords.isEmpty()) "Acordes não identificados com segurança." else
                estimate.chords.joinToString("   ·   ") { "${clock(it.second.toDouble())} ${it.name}?" }
        } else if(saved!=null) {
            harmonyStatus.text="Tonalidade confirmada: ${saved.key} · salva no repertório"
            harmonyChords.text=if(saved.chords.isEmpty()) "Sem sugestões de acordes salvas." else
                saved.chords.joinToString("   ·   ") { "${clock(it.second.toDouble())} ${it.name}?" }
        } else {
            harmonyStatus.text="Tonalidade: não analisada"
            harmonyChords.text="Análise aproximada; a correção manual fica disponível antes de salvar."
        }
    }
    private fun analyzeHarmony() {
        if(harmonyBusy)return
        val p=player.project ?: run {
            harmonyStatus.text="Escolha uma música salva no repertório.";return
        }
        val song=selectedId() ?: return
        if(!p.pcmFile.isFile){harmonyStatus.text="Áudio original não encontrado.";return}
        val generation=++harmonyGeneration
        harmonyBusy=true
        harmonyStatus.text="Analisando tonalidade e acordes offline (até 36 s)…"
        Thread({
            val result=try { StageHarmonyAnalyzer.analyze(p.pcmFile,p.sampleRate,p.channels,p.frames) }
                catch(_:Exception) {null}
            handler.post {
                if(generation!=harmonyGeneration || selectedId()!=song || isFinishing || isDestroyed)return@post
                harmonyBusy=false
                recentHarmony=result
                refreshHarmony()
                if(result==null) harmonyStatus.text="Análise inconclusiva. Corrija a tonalidade manualmente."
            }
        },"beatflow-harmony-analysis").start()
    }
    private fun correctHarmony() {
        if(selectedId()==null){harmonyStatus.text="Escolha uma música primeiro.";return}
        val candidates=StageHarmonyAnalyzer.noteNames.flatMap{listOf(it,it+"m")}
        MaterialAlertDialogBuilder(this).setTitle("Confirmar ou corrigir a tonalidade")
            .setItems(candidates.toTypedArray()){_,index ->
                val previous=recentHarmony
                recentHarmony=StageHarmonyAnalyzer.Analysis(candidates[index],
                    previous?.confidence ?: 0.0, previous?.chords.orEmpty())
                refreshHarmony()
            }.setNegativeButton("Cancelar",null).show()
    }
    private fun saveHarmony() {
        val set=current() ?:return
        val song=selectedId() ?:return
        val result=recentHarmony ?:run{harmonyStatus.text="Analise ou corrija a tonalidade antes de salvar.";return}
        val key=result.key ?:run{harmonyStatus.text="Tonalidade inconclusiva. Escolha em Corrigir tom.";return}
        val value=StageSetlists.Harmony(key,result.chords.take(12))
        save(set.copy(harmonies=set.harmonies+(song to value)))
        recentHarmony=null
        refreshHarmony()
    }
    private fun updateTempoStatus(detail:String?=null) {''','harmony functions')
s=change(s,'''        tempoGeneration++
        tempoBusy=false
        tapTimes.clear()''','''        tempoGeneration++
        tempoBusy=false
        harmonyGeneration++
        harmonyBusy=false
        recentHarmony=null
        tapTimes.clear()''','harmony reset on song change')
stage.write_text(s,encoding='utf-8')

ss=setlists.read_text(encoding='utf-8')
ss=change(ss,'''    data class Setlist(val id: String, val title: String,
                       val songIds: List<String>, val lyrics: Map<String, String>,
                       val tempos: Map<String, Int> = emptyMap())''','''    data class Harmony(val key: String, val chords: List<StageHarmonyAnalyzer.ChordHint>)
    data class Setlist(val id: String, val title: String,
                       val songIds: List<String>, val lyrics: Map<String, String>,
                       val tempos: Map<String, Int> = emptyMap(),
                       val harmonies: Map<String, Harmony> = emptyMap())''','harmonic metadata fields')
ss=change(ss,'''                result.add(Setlist(id, row.optString("title").take(70), songs, lyrics, tempos))''','''                val harmonies=HashMap<String,Harmony>()
                val stored=row.optJSONObject("harmonies") ?: JSONObject()
                val validKeys=StageHarmonyAnalyzer.noteNames.flatMap {listOf(it,it+"m")}.toSet()
                for(song in songs) {
                    val info=stored.optJSONObject(song) ?:continue
                    val key=info.optString("key")
                    if(key !in validKeys)continue
                    val hints=ArrayList<StageHarmonyAnalyzer.ChordHint>()
                    val list=info.optJSONArray("chords") ?: JSONArray()
                    for(j in 0 until minOf(list.length(),12)) {
                        val chord=list.optJSONObject(j) ?:continue
                        val second=chord.optInt("second",-1)
                        val name=chord.optString("name")
                        if(second in 0..3600 && name in validKeys)
                            hints.add(StageHarmonyAnalyzer.ChordHint(second,name,0.0))
                    }
                    harmonies[song]=Harmony(key,hints)
                }
                result.add(Setlist(id, row.optString("title").take(70), songs, lyrics, tempos, harmonies))''','read harmony')
ss=change(ss,'''            array.put(row)
        }
        val target = AtomicFile(file(context))''','''            row.put("harmonies",JSONObject().also { saved ->
                val validKeys=StageHarmonyAnalyzer.noteNames.flatMap {listOf(it,it+"m")}.toSet()
                for((song,harmony) in set.harmonies) if(song in set.songIds && harmony.key in validKeys) {
                    saved.put(song,JSONObject().apply {
                        put("key",harmony.key)
                        put("chords",JSONArray().also { seq ->
                            harmony.chords.take(12).forEach { hint ->
                                if(hint.second in 0..3600 && hint.name in validKeys)
                                    seq.put(JSONObject().put("second",hint.second).put("name",hint.name))
                            }
                        })
                    })
                }
            })
            array.put(row)
        }
        val target = AtomicFile(file(context))''','write harmony')
setlists.write_text(ss,encoding='utf-8')

gradle=root/'app/build.gradle.kts'
g=gradle.read_text(encoding='utf-8')
g=change(g,'versionCode = 47','versionCode = 48','versionCode')
g=change(g,'versionName = "1.13.6"','versionName = "1.13.7"','versionName')
gradle.write_text(g,encoding='utf-8')
print('v1.13.7: offline harmonic suggestions, manual key confirmation, persisted key/chords.')

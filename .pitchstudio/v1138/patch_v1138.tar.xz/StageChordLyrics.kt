package br.com.timachado.pitchstudio

/** Only decorates a view. The raw lyric text and PCM are never mutated. */
internal object StageChordLyrics {
    const val MAX_LINES = 500
    const val MAX_CHORDS = 12
    val names: List<String> = StageHarmonyAnalyzer.noteNames.flatMap { listOf(it, "${it}m") }

    fun lines(raw: String): List<String> = if (raw.isBlank()) emptyList()
        else raw.split('\n').take(MAX_LINES)

    fun normalized(hints: List<StageHarmonyAnalyzer.ChordHint>, raw: String): List<StageHarmonyAnalyzer.ChordHint> {
        val size = lines(raw).size
        return hints.take(MAX_CHORDS).map { hint ->
            val line = hint.lyricLine?.takeIf { it in 0 until size }
            hint.copy(lyricLine = line)
        }.sortedWith(compareBy<StageHarmonyAnalyzer.ChordHint> { it.second }.thenBy { it.name })
    }

    fun render(raw: String, hints: List<StageHarmonyAnalyzer.ChordHint>): String {
        val lines = lines(raw)
        if (lines.isEmpty()) return raw
        val associated = normalized(hints,raw).filter { it.lyricLine != null }.groupBy { it.lyricLine!! }
        return lines.mapIndexed { index, line ->
            val chords = associated[index]?.joinToString("    ") { "[${it.name}]" }
            if (chords.isNullOrEmpty()) line else "$chords\n$line"
        }.joinToString("\n")
    }

    fun edit(hints: List<StageHarmonyAnalyzer.ChordHint>, index: Int,
             replacement: StageHarmonyAnalyzer.ChordHint?): List<StageHarmonyAnalyzer.ChordHint> {
        require(index in hints.indices)
        return hints.toMutableList().also { if(replacement==null) it.removeAt(index) else it[index]=replacement }
            .sortedWith(compareBy<StageHarmonyAnalyzer.ChordHint> { it.second }.thenBy { it.name })
    }
}

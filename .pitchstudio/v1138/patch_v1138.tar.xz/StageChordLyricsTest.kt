package br.com.timachado.pitchstudio

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class StageChordLyricsTest {
    private fun hint(s:Int,n:String,l:Int?=null)=StageHarmonyAnalyzer.ChordHint(s,n,1.0,l)

    @Test fun chordAppearsAboveSelectedLineWithoutChangingRawLyrics() {
        val raw="Primeiro verso\nSegundo verso\nRefrão"
        val seq=listOf(hint(2,"C",0),hint(8,"G",2),hint(9,"F",2))
        assertEquals("[C]\nPrimeiro verso\nSegundo verso\n[G]    [F]\nRefrão",
            StageChordLyrics.render(raw,seq))
        assertEquals("Primeiro verso\nSegundo verso\nRefrão",raw)
    }
    @Test fun ignoreOutOfRangeLineAndPreserveUnlinkedChord() {
        val raw="Linha única"
        assertEquals(raw,StageChordLyrics.render(raw,listOf(hint(0,"C",7),hint(3,"F"))))
        assertNull(StageChordLyrics.normalized(listOf(hint(0,"C",7)),raw).first().lyricLine)
    }
    @Test fun editKeepsOrderAndAllowsRemoval() {
        val original=listOf(hint(20,"C"),hint(40,"G"))
        val edited=StageChordLyrics.edit(original,1,hint(10,"F",0))
        assertTrue(edited.map { it.name }==listOf("F","C"))
        assertEquals(1,StageChordLyrics.edit(edited,0,null).size)
        assertEquals(2,original.size)
    }
    @Test fun noLyricsPreservesEmptyOutputAndLimitsExcessiveLinks() {
        assertEquals("",StageChordLyrics.render("",listOf(hint(0,"C",0))))
        assertEquals(StageChordLyrics.MAX_LINES,StageChordLyrics.lines((1..900).joinToString("\n") { "x" }).size)
    }
}

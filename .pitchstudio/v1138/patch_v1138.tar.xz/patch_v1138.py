#!/usr/bin/env python3
"""Incremental BEAT flow 1.13.8: review per-chord + align chord with lyric line."""
import sys
from pathlib import Path
root=Path(sys.argv[1]).resolve()
pkg=root/'app/src/main/java/br/com/timachado/pitchstudio'

def change(path,old,new):
    src=path.read_text(encoding='utf8')
    if src.count(old)!=1: raise RuntimeError(f'Unexpected base for {path.name}: {old[:65]} (matches={src.count(old)})')
    path.write_text(src.replace(old,new,1),encoding='utf8')

harmony=pkg/'StageHarmonyAnalyzer.kt'
change(harmony,'data class ChordHint(val second: Int, val name: String, val confidence: Double)',
    'data class ChordHint(val second: Int, val name: String, val confidence: Double, val lyricLine: Int? = null)')

store=pkg/'StageSetlists.kt'
change(store,
    'hints.add(StageHarmonyAnalyzer.ChordHint(second,name,0.0))',
    '''hints.add(StageHarmonyAnalyzer.ChordHint(second,name,0.0,
                                chord.optInt("line",-1).takeIf { it in 0 until
                                    StageChordLyrics.lines(lyrics[song].orEmpty()).size }))''')
change(store,
    '''                                    seq.put(JSONObject().put("second",hint.second).put("name",hint.name))''',
    '''                                    seq.put(JSONObject().put("second",hint.second).put("name",hint.name).apply {
                                        hint.lyricLine?.takeIf { it in 0 until
                                            StageChordLyrics.lines(set.lyrics[song].orEmpty()).size }?.let { put("line",it) }
                                    })''')

stage=pkg/'StageActivity.kt'
change(stage,
    '''        column.addView(harmonyActions,full(top=4))
        harmonyChords=text''',
    '''        column.addView(harmonyActions,full(top=4))
        val chordActions=row()
        rowBtn(chordActions,"Editar acordes") { editChords() }
        rowBtn(chordActions,"Adicionar acorde") { addChordAtPlayhead() }
        column.addView(chordActions,full(top=4))
        harmonyChords=text''')
change(stage,
    '''        if (::harmonyStatus.isInitialized) refreshHarmony()
    }
    // Controles locais de palco/ensaio''',
    '''        if (::harmonyStatus.isInitialized) refreshHarmony()
    }
    // Controles locais de palco/ensaio''') if False else None
# Introduce raw lyric decoration after full refresh and whenever harmony draft changes.
change(stage,
    '''    private fun refreshHarmony() {
        if (!::harmonyStatus.isInitialized) return''',
    '''    private fun harmonyDraft(): StageHarmonyAnalyzer.Analysis? {
        val saved=selectedId()?.let { current()?.harmonies?.get(it) }
        return recentHarmony ?: saved?.let {
            StageHarmonyAnalyzer.Analysis(it.key,1.0,it.chords)
        }
    }
    private fun refreshLyricAnnotations() {
        if(!::lyrics.isInitialized)return
        val raw=selectedId()?.let { current()?.lyrics?.get(it) }.orEmpty()
        if(raw.isBlank()) return
        lyrics.text=StageChordLyrics.render(raw,harmonyDraft()?.chords.orEmpty())
    }
    private fun refreshHarmony() {
        if (!::harmonyStatus.isInitialized) return''')
change(stage,
    '''            harmonyChords.text="Análise aproximada; a correção manual fica disponível antes de salvar."
        }
    }
    private fun analyzeHarmony()''',
    '''            harmonyChords.text="Análise aproximada; a correção manual fica disponível antes de salvar."
        }
        refreshLyricAnnotations()
    }
    private fun analyzeHarmony()''')
change(stage,
    '''                val previous=recentHarmony
                recentHarmony=StageHarmonyAnalyzer.Analysis(candidates[index],''',
    '''                val previous=harmonyDraft()
                recentHarmony=StageHarmonyAnalyzer.Analysis(candidates[index],''')
change(stage,
    '''        val value=StageSetlists.Harmony(key,result.chords.take(12))''',
    '''        val raw=set.lyrics[song].orEmpty()
        val value=StageSetlists.Harmony(key,StageChordLyrics.normalized(result.chords,raw))''')

# New chord controls are usable only in Ensaio, protecting the performance UI.
newmethods='''    private fun editChords() {
        if(stageMode) {status.text="Corrija os acordes no Modo Ensaio.";return}
        if(selectedId()==null){status.text="Selecione uma música.";return}
        val all=harmonyDraft()?.chords.orEmpty()
        if(all.isEmpty()) {status.text="Analise ou adicione um acorde primeiro.";return}
        val options=all.map { "${clock(it.second.toDouble())} · ${it.name}" }.toTypedArray()
        MaterialAlertDialogBuilder(this).setTitle("Editar acordes individuais")
            .setItems(options) {_,index -> editChordOptions(index) }
            .setNegativeButton("Cancelar",null).show()
    }
    private fun updateChordDraft(chords:List<StageHarmonyAnalyzer.ChordHint>) {
        val previous=harmonyDraft()
        recentHarmony=StageHarmonyAnalyzer.Analysis(previous?.key,previous?.confidence ?: 0.0,
            StageChordLyrics.normalized(chords,selectedId()?.let{current()?.lyrics?.get(it)}.orEmpty()))
        refreshHarmony()
        status.text="Prévia de harmonia editada. Toque em Salvar harmonia para confirmar."
    }
    private fun editChordOptions(index:Int) {
        val chord=harmonyDraft()?.chords?.getOrNull(index) ?:return
        MaterialAlertDialogBuilder(this).setTitle("${clock(chord.second.toDouble())} · ${chord.name}")
            .setItems(arrayOf("Corrigir acorde","Vincular à linha da letra",
                "Alterar tempo (segundos)","Remover acorde","Ouvir nesse ponto")) {_,choice ->
                when(choice) {
                    0 -> chooseChordName(index)
                    1 -> linkChordLine(index)
                    2 -> editChordTime(index)
                    3 -> updateChordDraft(StageChordLyrics.edit(harmonyDraft()!!.chords,index,null))
                    4 -> if(songDuration()>0.0)player.seekFraction((chord.second/songDuration()).coerceIn(0.0,1.0))
                }
            }.setNegativeButton("Cancelar",null).show()
    }
    private fun chooseChordName(index:Int) {
        val draft=harmonyDraft() ?:return
        if(index !in draft.chords.indices)return
        MaterialAlertDialogBuilder(this).setTitle("Selecionar acorde")
            .setItems(StageChordLyrics.names.toTypedArray()) {_,selection ->
                val updated=draft.chords[index].copy(name=StageChordLyrics.names[selection],confidence=1.0)
                updateChordDraft(StageChordLyrics.edit(draft.chords,index,updated))
            }.setNegativeButton("Cancelar",null).show()
    }
    private fun linkChordLine(index:Int) {
        val id=selectedId() ?:return
        val raw=current()?.lyrics?.get(id).orEmpty()
        val lines=StageChordLyrics.lines(raw)
        if(lines.isEmpty()) {status.text="Cadastre primeiro a letra em Editar letra.";return}
        val draft=harmonyDraft() ?:return
        if(index !in draft.chords.indices)return
        val choices=(listOf("Sem vínculo")+lines.mapIndexed {number,line ->
            "${number+1}. ${line.take(58).ifBlank { "(linha vazia)" }}"
        }).toTypedArray()
        MaterialAlertDialogBuilder(this).setTitle("Vincular acorde à linha")
            .setItems(choices) {_,selected ->
                val updated=draft.chords[index].copy(lyricLine=if(selected==0)null else selected-1,confidence=1.0)
                updateChordDraft(StageChordLyrics.edit(draft.chords,index,updated))
            }.setNegativeButton("Cancelar",null).show()
    }
    private fun editChordTime(index:Int) {
        val draft=harmonyDraft() ?:return
        if(index !in draft.chords.indices)return
        val input=EditText(this).apply {
            inputType=android.text.InputType.TYPE_CLASS_NUMBER
            setText(draft.chords[index].second.toString())
            setSelectAllOnFocus(true)
            setPadding(dp(20),dp(14),dp(20),dp(14))
        }
        MaterialAlertDialogBuilder(this).setTitle("Tempo em segundos (0–3600)")
            .setView(input).setPositiveButton("Aplicar") {_,_ ->
                val seconds=input.text.toString().toIntOrNull()
                if(seconds==null || seconds !in 0..3600 ||
                    (songDuration()>0 && seconds>songDuration())) {
                    status.text="Tempo inválido ou maior que a música."
                } else {
                    val changed=draft.chords[index].copy(second=seconds,confidence=1.0)
                    updateChordDraft(StageChordLyrics.edit(draft.chords,index,changed))
                }
            }.setNegativeButton("Cancelar",null).show()
    }
    private fun addChordAtPlayhead() {
        if(stageMode){status.text="Adicione acordes no Modo Ensaio.";return}
        if(selectedId()==null || player.project==null){status.text="Escolha uma música.";return}
        val existing=harmonyDraft()?.chords.orEmpty()
        if(existing.size>=StageChordLyrics.MAX_CHORDS) {
            status.text="Máximo de 12 acordes. Remova um marcador antes.";return
        }
        val second=(player.fraction()*songDuration()).toInt().coerceIn(0,3600)
        MaterialAlertDialogBuilder(this).setTitle("Acorde em ${clock(second.toDouble())}")
            .setItems(StageChordLyrics.names.toTypedArray()) {_,selection ->
                updateChordDraft(existing+StageHarmonyAnalyzer.ChordHint(second,
                    StageChordLyrics.names[selection],1.0))
            }.setNegativeButton("Cancelar",null).show()
    }
'''
change(stage,
    '''    private fun updateTempoStatus(detail:String?=null) {''',
    newmethods+'''    private fun updateTempoStatus(detail:String?=null) {''')
# Clear potentially stale draft when switching repertory or creating it, not just selecting a song.
change(stage,
    '''                setlistId=items[which].id;selectedIndex=-1''',
    '''                harmonyGeneration++;recentHarmony=null;harmonyBusy=false
                setlistId=items[which].id;selectedIndex=-1''')
change(stage,
    '''                    setlistId=created.id;selectedIndex=-1''',
    '''                    harmonyGeneration++;recentHarmony=null;harmonyBusy=false
                    setlistId=created.id;selectedIndex=-1''')
change(stage,
    '''                selectedIndex=-1;setlistId=null''',
    '''                selectedIndex=-1;setlistId=null
                harmonyGeneration++;recentHarmony=null;harmonyBusy=false''')
# A saved chord is shown as confirmed. Unconfirmed acoustic suggestions use ?.  
change(stage,
    '''                saved.chords.joinToString("   ·   ") { "${clock(it.second.toDouble())} ${it.name}?" }''',
    '''                saved.chords.joinToString("   ·   ") { "${clock(it.second.toDouble())} ${it.name}" }''')

build=root/'app/build.gradle.kts'
change(build, 'versionCode = 48','versionCode = 49')
change(build, 'versionName = "1.13.7"','versionName = "1.13.8"')
print('BEAT flow v1.13.8: individual chord correction and lyric alignment integrated.')

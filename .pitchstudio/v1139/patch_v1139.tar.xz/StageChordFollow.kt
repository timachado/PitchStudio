package br.com.timachado.pitchstudio

/** Pure, offline playback-to-cipher cues. Never touches the stored lyrics or audio. */
internal object StageChordFollow {
    data class Cue(
        val index: Int,
        val current: StageHarmonyAnalyzer.ChordHint?,
        val next: StageHarmonyAnalyzer.ChordHint?
    )

    fun cue(hints: List<StageHarmonyAnalyzer.ChordHint>, seconds: Double): Cue {
        if (!seconds.isFinite() || seconds < 0.0) return Cue(-1, null, null)
        val ordered = hints.asSequence().filter { it.second in 0..3600 }
            .sortedWith(compareBy<StageHarmonyAnalyzer.ChordHint> { it.second }.thenBy { it.name })
            .take(StageChordLyrics.MAX_CHORDS).toList()
        val i = ordered.indexOfLast { it.second.toDouble() <= seconds }
        return Cue(i, ordered.getOrNull(i), ordered.getOrNull(i + 1))
    }

    /** [start, endExclusive) of the linked ORIGINAL lyric row in the decorated text. */
    fun lyricSpan(raw: String, hints: List<StageHarmonyAnalyzer.ChordHint>, lineIndex: Int?): IntRange? {
        val rows = StageChordLyrics.lines(raw)
        val target = lineIndex?.takeIf { it in rows.indices } ?: return null
        val attached = StageChordLyrics.normalized(hints, raw)
            .filter { it.lyricLine != null }.groupBy { it.lyricLine!! }
        var cursor = 0
        for ((i, line) in rows.withIndex()) {
            val prefix = attached[i]?.joinToString("    ") { "[${it.name}]" }
            if (!prefix.isNullOrEmpty()) cursor += prefix.length + 1 // annotation plus newline
            if (i == target) {
                if (line.isEmpty()) return null
                return cursor until (cursor + line.length)
            }
            cursor += line.length + 1 // lyric line plus newline
        }
        return null
    }
}

package br.com.timachado.pitchstudio

import org.junit.Assert.*
import org.junit.Test

class StageChordFollowTest {
    private fun c(s: Int, name: String, line: Int? = null) =
        StageHarmonyAnalyzer.ChordHint(s, name, 1.0, line)

    @Test fun boundaryAndScrubBehaviors() {
        val chords = listOf(c(20,"G",1), c(5,"C",0),c(36,"Am",2))
        val before=StageChordFollow.cue(chords, 0.0)
        assertNull(before.current)
        assertEquals("C", before.next?.name)
        assertEquals("C",StageChordFollow.cue(chords,5.0).current?.name)
        assertEquals("G",StageChordFollow.cue(chords,20.1).current?.name)
        assertEquals("Am",StageChordFollow.cue(chords,99.0).current?.name)
        assertNull(StageChordFollow.cue(chords,99.0).next)
        assertEquals("C",StageChordFollow.cue(chords,6.0).current?.name)
    }

    @Test fun invalidTimesAndEmptySequence() {
        assertNull(StageChordFollow.cue(emptyList(),3.0).current)
        assertNull(StageChordFollow.cue(listOf(c(4,"C")),Double.NaN).current)
        assertNull(StageChordFollow.cue(listOf(c(4,"C")),-2.0).current)
        assertNull(StageChordFollow.cue(listOf(c(4001,"C")),4002.0).current)
    }

    @Test fun highlightedSpanIncludesOnlyOriginalLyricRow() {
        val raw="Primeiro verso\nSegundo verso\nRefrão final"
        val chords=listOf(c(2,"C",0),c(4,"F",2),c(8,"G",2))
        val display=StageChordLyrics.render(raw,chords)
        val span=StageChordFollow.lyricSpan(raw,chords,2)!!
        assertEquals("Refrão final",display.substring(span.first, span.last + 1))
        assertEquals("Primeiro verso",raw.substringBefore('\n'))
        val first=StageChordFollow.lyricSpan(raw,chords,0)!!
        assertEquals("Primeiro verso",display.substring(first.first,first.last+1))
        assertNull(StageChordFollow.lyricSpan(raw,chords,99))
    }

    @Test fun unlinkedChordCannotMoveTheLyricsAndBlanksAreSafe() {
        val raw="Verso\n\nOutro"
        val chords=listOf(c(2,"C"),c(4,"F",2))
        assertNull(StageChordFollow.lyricSpan(raw,chords,1))
        val display=StageChordLyrics.render(raw,chords)
        val span=StageChordFollow.lyricSpan(raw,chords,2)!!
        assertEquals("Outro",display.substring(span.first,span.last+1))
        assertEquals("Verso\n\nOutro",raw)
    }
}

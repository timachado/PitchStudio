#!/usr/bin/env python3
"""BEAT flow v1.13.9: read-only following of saved chords during playback.

Only StageActivity, version metadata and two NEW source files. Existing playback,
Voz, YouTube and export paths are intentionally untouched.
"""
from pathlib import Path
import sys

src=Path(sys.argv[1]).resolve()
app=src/'app/src/main/java/br/com/timachado/pitchstudio/StageActivity.kt'
s=app.read_text(encoding='utf-8')
def change(old,new):
    global s
    if s.count(old)!=1:
        raise RuntimeError(f'StageActivity base changed: {old[:90]!r}, matches={s.count(old)}')
    s=s.replace(old,new,1)

change('import android.graphics.Color\n', '''import android.graphics.Color
import android.text.SpannableString
import android.text.Spanned
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
''')
change('    private lateinit var harmonyChords: TextView\n', '''    private lateinit var harmonyChords: TextView
    private lateinit var liveChord: TextView
    private lateinit var nextChord: TextView
    private lateinit var followChordButton: MaterialButton
    private var followChords=false
    private var cueSong: String?=null
    private var cueHints: List<StageHarmonyAnalyzer.ChordHint> = emptyList()
    private var lastCueIndex=Int.MIN_VALUE
''')
change('''                refreshTransport()
                handler.postDelayed(this, 650)''','''                refreshTransport()
                refreshLiveChords()
                handler.postDelayed(this, 650)''')
change('''        harmonyChords=text("Acordes sugeridos aparecerão aqui; confirme pelo ouvido.",13f)
        column.addView(harmonyChords,full(top=4))''','''        harmonyChords=text("Acordes sugeridos aparecerão aqui; confirme pelo ouvido.",13f)
        column.addView(harmonyChords,full(top=4))
        liveChord=text("Acorde atual: —",21f,true)
        column.addView(liveChord,full(top=10))
        nextChord=text("Próximo acorde: —",14f)
        column.addView(nextChord,full(top=1))
        followChordButton=btn("Seguir cifras: desligado") { toggleChordFollow() }
        column.addView(followChordButton,full(dp(50),top=6))''')
change('''    private fun toggleLyricsScroll() {
        if (lyricsAutoScroll) stopLyricsScroll(false) else {
            lyricsAutoScroll=true''','''    private fun toggleLyricsScroll() {
        if (lyricsAutoScroll) stopLyricsScroll(false) else {
            // Escolher a rolagem livre desliga acompanhamento por cifras.
            if(followChords) {
                followChords=false
                followChordButton.text="Seguir cifras: desligado"
                refreshLyricAnnotations()
            }
            lyricsAutoScroll=true''')
change('''        refreshLyricAnnotations()
    }
    private fun analyzeHarmony()''','''        cueSong=selectedId()
        cueHints=estimate?.chords ?: saved?.chords.orEmpty()
        lastCueIndex=Int.MIN_VALUE
        refreshLyricAnnotations()
        refreshLiveChords(true)
    }
    private fun toggleChordFollow() {
        if(selectedId()==null || player.project==null) {
            status.text="Escolha uma música do repertório para acompanhar as cifras."
            return
        }
        followChords=!followChords
        if(followChords) stopLyricsScroll(false)
        followChordButton.text=if(followChords) "Seguir cifras: ligado" else "Seguir cifras: desligado"
        lastCueIndex=Int.MIN_VALUE
        refreshLiveChords(true)
    }
    private fun refreshLiveChords(force:Boolean=false) {
        if(!::liveChord.isInitialized || !::lyrics.isInitialized) return
        val song=selectedId()
        if(song==null || song!=cueSong || player.project==null) {
            liveChord.text="Acorde atual: —"
            nextChord.text="Próximo acorde: —"
            return
        }
        val seconds=player.fraction()*songDuration()
        val cue=StageChordFollow.cue(cueHints,seconds)
        // Não reescrever o TextView 2x/segundo: apenas nas mudanças de acorde.
        if(!force && cue.index==lastCueIndex) return
        lastCueIndex=cue.index
        liveChord.text="Acorde atual: ${cue.current?.name ?: "—"}"
        nextChord.text=if(cue.next==null) "Próximo acorde: —" else
            "Próximo acorde: ${cue.next.name} · ${clock(cue.next.second.toDouble())}"
        if(!followChords) {
            if(force) refreshLyricAnnotations()
            return
        }
        val raw=current()?.lyrics?.get(song).orEmpty()
        if(raw.isBlank()) return
        val display=StageChordLyrics.render(raw,cueHints)
        val span=StageChordFollow.lyricSpan(raw,cueHints,cue.current?.lyricLine)
        val styled=SpannableString(display)
        if(span!=null && span.first>=0 && span.last<styled.length) {
            styled.setSpan(BackgroundColorSpan(Color.rgb(19,99,91)),span.first,
                span.last+1,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            styled.setSpan(ForegroundColorSpan(Color.WHITE),span.first,
                span.last+1,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        lyrics.text=styled
        if(span!=null) lyrics.post {
            if(!followChords || selectedId()!=song || cue.index!=lastCueIndex) return@post
            val layout=lyrics.layout ?: return@post
            val row=layout.getLineForOffset(span.first.coerceAtMost(styled.length))
            val y=(layout.getLineTop(row)-lyricsScroll.height/3).coerceAtLeast(0)
            lyricsScroll.smoothScrollTo(0,y)
        }
    }
    private fun analyzeHarmony()''')
change('''        recentHarmony=null
        tapTimes.clear()
        val id=set.songIds.getOrNull(index) ?: return''','''        recentHarmony=null
        cueSong=null
        cueHints=emptyList()
        lastCueIndex=Int.MIN_VALUE
        tapTimes.clear()
        val id=set.songIds.getOrNull(index) ?: return''')

app.write_text(s,encoding='utf-8')
gradle=src/'app/build.gradle.kts'
g=gradle.read_text(encoding='utf-8')
for old,new in [('versionCode = 49','versionCode = 50'),('versionName = "1.13.8"','versionName = "1.13.9"')]:
    if g.count(old)!=1:raise RuntimeError('Wrong base version: '+old)
    g=g.replace(old,new,1)
gradle.write_text(g,encoding='utf-8')
print('PASSOU: v1.13.9, acompanhamento de cifras somente leitura integrado.')
